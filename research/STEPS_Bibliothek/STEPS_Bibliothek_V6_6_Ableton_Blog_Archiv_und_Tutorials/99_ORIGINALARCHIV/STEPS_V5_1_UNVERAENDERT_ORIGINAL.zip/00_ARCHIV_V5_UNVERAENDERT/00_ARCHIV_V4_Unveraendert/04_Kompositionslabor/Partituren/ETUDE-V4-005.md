# ETUDE-V4-005 – Lydische Weite

**Kontext:** C lydian; Stil-Studie: modal; Tempo 78 BPM; Metrum 4/4. **Form:** A (1–4) / A-Variation (5–8) / B-Contrast (9–12) / A-Return (13–16).

**Kompositorische Idee:** F# als mögliche melodische Farbe. Das Stück umfasst vollständig zeitlich definierte 16 Takte, vier melodische Phrasen, einen Bass und Akkordbegleitung. Es ist eine eigene computergenerierte **Unterrichtsminiatur**, keine ausnotierte professionelle Komposition und keine Transkription.

**Arbeitsentscheidung:** Wiederholung eines 8er-Konturfeldes mit phrasaler Umgruppierung und Kontrast in B. Die Melodie verwendet in dieser Fassung überwiegend Akkordtöne; nichtharmonische melodische Spannung ist eine spätere bewusste Revision, nicht ein übersehener Datenfehler.

| Takt | Akkord | Melodie (Ton: Viertelzählzeiten) | Bass | Abschnitt |
|---:|---|---|---|---|
| 1 | C | G4:1.0; C5:0.5; E4:0.5; C5:1.0; E4:1.0 | C2; C2 | A |
| 2 | C | C4:1.0; E4:0.5; G4:0.5; C4:1.0; E4:1.0 | C2; C2 | A |
| 3 | D | D4:1.0; A4:0.5; D5:0.5; Gb4:1.0; A4:1.0 | D2; A2 | A |
| 4 | D | Gb4:0.5; A4:0.5; D5:1.0; Gb4:2.0 | D2; D2 | A |
| 5 | C | E4:1.0; G4:0.5; C5:0.5; G4:1.0; C5:1.0 | C2; C2 | A-Variation |
| 6 | C | G4:1.0; C5:0.5; E4:0.5; G4:1.0; C5:1.0 | C2; C2 | A-Variation |
| 7 | Em | B4:1.0; G4:0.5; B4:0.5; E5:1.0; G4:1.0 | E2; B2 | A-Variation |
| 8 | Em | E4:0.5; G4:0.5; B4:1.0; E4:2.0 | E2; E2 | A-Variation |
| 9 | C | C4:1.0; E5:0.5; G4:0.5; E5:1.0; G4:1.0 | C2; C2 | B-Contrast |
| 10 | C | E4:1.0; G4:0.5; C5:0.5; E4:1.0; G4:1.0 | C2; C2 | B-Contrast |
| 11 | D | Gb4:1.0; D5:0.5; Gb5:0.5; A4:1.0; D5:1.0 | D2; A2 | B-Contrast |
| 12 | D | A4:0.5; D5:0.5; Gb5:1.0; A4:2.0 | D2; D2 | B-Contrast |
| 13 | G | D4:1.0; G4:0.5; B4:0.5; G4:1.0; B4:1.0 | G2; G2 | A-Return |
| 14 | G | G4:1.0; B4:0.5; D4:0.5; G4:1.0; B4:1.0 | G2; G2 | A-Return |
| 15 | C | C4:1.0; G4:0.5; C5:0.5; E5:1.0; G4:1.0 | C2; G2 | A-Return |
| 16 | C | E4:0.5; G4:0.5; C5:1.0; E4:2.0 | C2; C2 | A-Return |

### Kompositorische Weiterarbeit

1. Höre den MIDI-Entwurf ohne Begleitung und markiere die wiedererkennbare Kontur.
2. Verändere in der B-Phrase einen Zielton und prüfe sein Verhältnis zum Akkord.
3. Schreibe einen melodisch glaubwürdigen Vorhalt oder Durchgang auf eine schwache Zählzeit.
4. Vergleiche die Schlusswirkung mit einer Version, die den Harmonic Rhythm der letzten zwei Takte verdichtet.
5. Überarbeite Klangdichte und Register für eine konkrete Besetzung und dokumentiere die Entscheidung.

**Review-Grenze:** Die MIDI- und Taktintegrität ist mechanisch testbar. Motivqualität, Stimmführungsstil, Balance, eine historisch korrekte Forminterpretation und musikalische Originalität bedürfen menschlicher Begutachtung.
