# ETUDE-V4-014 – Plateau ohne explizites I

**Kontext:** C-centric ambiguous; Stil-Studie: pop; Tempo 108 BPM; Metrum 4/4. **Form:** A (1–4) / A-Variation (5–8) / B-Contrast (9–12) / A-Return (13–16).

**Kompositorische Idee:** IV–V–vi als stilistisch zu prüfender Loop. Das Stück umfasst vollständig zeitlich definierte 16 Takte, vier melodische Phrasen, einen Bass und Akkordbegleitung. Es ist eine eigene computergenerierte **Unterrichtsminiatur**, keine ausnotierte professionelle Komposition und keine Transkription.

**Arbeitsentscheidung:** Wiederholung eines 8er-Konturfeldes mit phrasaler Umgruppierung und Kontrast in B. Die Melodie verwendet in dieser Fassung überwiegend Akkordtöne; nichtharmonische melodische Spannung ist eine spätere bewusste Revision, nicht ein übersehener Datenfehler.

| Takt | Akkord | Melodie (Ton: Viertelzählzeiten) | Bass | Abschnitt |
|---:|---|---|---|---|
| 1 | F | F4:1.0; A4:0.5; F4:0.5; A4:1.0; C5:1.0 | F2; F2 | A |
| 2 | F | A4:1.0; C5:0.5; F4:0.5; A4:1.0; C5:1.0 | F2; F2 | A |
| 3 | G | D5:1.0; G4:0.5; B4:0.5; D5:1.0; G4:1.0 | G2; D2 | A |
| 4 | G | D5:0.5; G4:0.5; B4:1.0; G4:2.0 | G2; G2 | A |
| 5 | Am | E4:1.0; A4:0.5; E4:0.5; A4:1.0; C5:1.0 | A2; A2 | A-Variation |
| 6 | Am | A4:1.0; C5:0.5; E4:0.5; A4:1.0; C5:1.0 | A2; A2 | A-Variation |
| 7 | G | B4:1.0; D5:0.5; G4:0.5; B4:1.0; D4:1.0 | G2; D2 | A-Variation |
| 8 | G | B4:0.5; D5:0.5; G4:1.0; D4:2.0 | G2; G2 | A-Variation |
| 9 | F | A4:1.0; C5:0.5; A4:0.5; C5:1.0; F5:1.0 | F2; F2 | B-Contrast |
| 10 | F | C5:1.0; F4:0.5; A4:0.5; C5:1.0; F4:1.0 | F2; F2 | B-Contrast |
| 11 | G | G4:1.0; B4:0.5; D5:0.5; G4:1.0; B4:1.0 | G2; D2 | B-Contrast |
| 12 | G | G4:0.5; B4:0.5; D5:1.0; B4:2.0 | G2; G2 | B-Contrast |
| 13 | Am | A4:1.0; C5:0.5; A4:0.5; C5:1.0; E5:1.0 | A2; A2 | A-Return |
| 14 | Am | C5:1.0; E4:0.5; A4:0.5; C5:1.0; E4:1.0 | A2; A2 | A-Return |
| 15 | Am | E4:1.0; A4:0.5; C5:0.5; E4:1.0; A4:1.0 | A2; E2 | A-Return |
| 16 | Am | E4:0.5; A4:0.5; C5:1.0; A4:2.0 | A2; A2 | A-Return |

### Kompositorische Weiterarbeit

1. Höre den MIDI-Entwurf ohne Begleitung und markiere die wiedererkennbare Kontur.
2. Verändere in der B-Phrase einen Zielton und prüfe sein Verhältnis zum Akkord.
3. Schreibe einen melodisch glaubwürdigen Vorhalt oder Durchgang auf eine schwache Zählzeit.
4. Vergleiche die Schlusswirkung mit einer Version, die den Harmonic Rhythm der letzten zwei Takte verdichtet.
5. Überarbeite Klangdichte und Register für eine konkrete Besetzung und dokumentiere die Entscheidung.

**Review-Grenze:** Die MIDI- und Taktintegrität ist mechanisch testbar. Motivqualität, Stimmführungsstil, Balance, eine historisch korrekte Forminterpretation und musikalische Originalität bedürfen menschlicher Begutachtung.
