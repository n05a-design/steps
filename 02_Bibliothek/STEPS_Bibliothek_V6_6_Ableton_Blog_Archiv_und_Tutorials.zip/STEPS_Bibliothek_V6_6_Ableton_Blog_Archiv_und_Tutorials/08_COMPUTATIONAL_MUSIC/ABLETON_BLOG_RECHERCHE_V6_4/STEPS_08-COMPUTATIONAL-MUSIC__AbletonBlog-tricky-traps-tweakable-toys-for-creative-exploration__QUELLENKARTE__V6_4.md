# Tricky Traps: Tweakable Toys for Creative Exploration — STEPS-Quellenkarte V6.4

**Dokument-ID:** `ABLETON-151` · **Stand:** 2026-11-09 · **Fachbereich:** `08_COMPUTATIONAL_MUSIC`  
**Originalartikel:** https://www.ableton.com/en/blog/tricky-traps/  
**Stichwörter:** Max for Live;Chance;Experimental Sequencing;Push  
**Typ:** News · **Verifikation:** `article_page_opened` (Original-Webseite oder offizielles Suchergebnis; keine vollständige audiovisuelle Begutachtung)

## Warum diese Quelle in STEPS steht

Anpassbare Sequencer-/Sound-Werkzeuge als Anregung zu explorativen Steuerparametern.

## Fachliche Einordnung und Grenzen

- **Direkter Quellenkontext:** Ableton-Artikel oder Künstlergespräch. Es ist keine externe wissenschaftliche Qualitätsbegutachtung.
- **Transferidee / Eigenleistung:** Computational-Music-Prototyp — Algorithmisches Prinzip in JSON-MIDI beschreiben und mit Seeds sowie Grenzfällen testen.
- **Gegenprüfung:** Ein Gerät oder Max-Patch beweist kein generelles musiktheoretisches Gesetz.
- **Verknüpfung:** Fachbereich `08_COMPUTATIONAL_MUSIC` und übergreifendes Quellenregister in `10_QUELLEN_LIZENZEN`.

## Was Codex damit tun soll

1. Link und Veröffentlichungsdatum erneut prüfen; falls der Artikel auf eine ältere Live-Version verweist, Release-Versionsbezug markieren.
2. Aus dem Original nur eigenständig beschriebene Begriffe, überprüfbare Schritte und eigene Beispiele in die STEPS-KB übernehmen; jede konkrete Behauptung mit Link und Abschnitt versehen.
3. Künstlerzitate/ästhetische Vorlieben als individuelle Aussagen kennzeichnen; niemals universell gültige Musikregeln ableiten.
4. Das oben vorgeschlagene Experiment mit **eigenen Noten, MIDI- und Audioartefakten** ausarbeiten und Hör-/Techniktest protokollieren.
5. Bei Assets Lizenz und Rechte individuell prüfen, bevor Dateien gespeichert, als Trainingsdaten verwendet oder veröffentlicht werden.

## Asset- und Qualitätsstatus

- Asset-Hinweis: `pack` / `asset_link_not_downloaded`.
- Wiedergabe des Originalartikels: **nicht enthalten**.
- Download, Lizenz, konkrete Nutzungsrechte: **nicht freigegeben** ohne separate Prüfung.
- Fachlicher Volltextreview, Video-/Audioanalyse und Tests im STEPS-Repo: **ausstehend**.
