# Creative Direction, Ideation & Pre-Production — STEPS Produktionsfachdossier V6.0

**Ablage:** `16_CREATIVE_DIRECTION_PREPRODUCTION`  
**Dokumentstatus:** redaktionelle Fachsynthese / Arbeits- und Forschungsrahmen; keine abschließende Peer-Review.  
**Taxonomie:** 22 benannte Einzelthemen; noch kein Nachweis, dass alle eine eigenständige geprüfte Quellenfundstelle besitzen.

## Gegenstand und Bedeutung
Aus einer kreativen Absicht wird ein begrenztes, ausführbares Produktionsbriefing. Zielgruppe, dramaturgische Idee, Referenzfunktion, Produktionsbudget, Zeitfenster und gewünschte Emotion werden getrennt von technischen Mitteln dokumentiert.

Im gesamten STEPS-Produktionssystem ist dieser Bereich eine **eigene fachliche Kompetenz** und nicht automatisch ein weiterer Akkordgenerator. Für die Anwendung sind drei unterschiedliche Nutzungsarten zu trennen: Theorie lernen, Produktionsentscheidungen vorbereiten und Dateien/Events tatsächlich maschinell verarbeiten. Jede Karte braucht einen klaren Output und die Frage, was beim Nutzer **hörbar** oder **nachvollziehbar** besser werden soll.

## Originaler Praxisfall: vollständig dokumentierbares Szenario
Ein Club-Track soll im Break zurückgenommen und im Drop durch Klangdichte statt bloße Lautheit wachsen. Das Briefing benennt Metrum, Form, Spannungsbogen, Energieprofil, Ausschlusskriterien und Referenzmerkmale, ohne die Referenz zu kopieren.

### Forschungs- und Produktionsablauf
1. Ausgangslage und musikalisches Ziel benennen; stilistische Aussagen als Hypothesen markieren.
2. Die zugehörigen Audio-/MIDI-/Session-Eingaben sowie die tatsächlich erlaubte Datenverwendung erfassen.
3. Mindestens zwei unterschiedliche Produktionsmethoden unter kontrollierten Randbedingungen vergleichen.
4. Entscheidung nach musikalischer Funktion, Aufwand, Nebenwirkungen, Hörtest und reproduzierbaren Messwerten treffen.
5. Artefakte (Daten, Diagramm, Render, Aufgabenstellung, Beschreibung) getrennt von Drittanbieter-Originalmaterial speichern.
6. Musikalisch wertende Aussagen durch mindestens eine fachkundige Hörprüfung ergänzen; Testbedingungen dokumentieren.

## Typische Fehlinterpretationen und Risikoüberprüfung
Referenzlautheit mit künstlerischer Qualität verwechseln; Produktion ohne Abschlussskriterien beginnen; Kreativbriefing mit Plug-in-Liste verwechseln.

**Review-Frage:** Kann der jeweilige Sachverhalt objektiv mit einem Zahlenwert bewiesen werden, oder ist das Ergebnis ein kontextabhängiges Hör-/Gestaltungsurteil? Das entscheidet über die Validierungsmethode.

## Fachliche Themenkarte
### Themencluster 1: Creative Brief, Produzentenrolle, Artist Identity, Zielgruppe, Musikalische Intention

**Was zu dokumentieren ist:** Für `Creative Brief` und die benachbarten Konzepte wird jeweils (a) die Definition aus der konkreten musikalischen oder technischen Perspektive, (b) Ein- und Ausgangsdaten, (c) ein realistischer Hör- oder Editierkontext, (d) typische Grenzfälle, (e) mögliche Export-/Lizenzrestriktionen und (f) ein prüfbarer Gegenfall benötigt. Nicht jedes benannte Thema ist im vorliegenden Dossier schon vollständig erarbeitet.

**STEPS-Umsetzung:** Das Cluster erhält separat versionierbare Skills bzw. Lernkarten. Eine konkrete STEPS-Funktion wird nur dann implementiert, wenn sie sich aus vorhandenen Daten, Instrumenten- oder Clip-Informationen ableiten lässt. Bei reiner Hör-/Stilbeurteilung ist der Test ein menschlicher Hörvergleich, keine binäre Software-Assertion.

### Themencluster 2: Referenztrack-Analyse, Moodboard, Demo und Skizze, Kreative Beschränkungen, Scope

**Was zu dokumentieren ist:** Für `Referenztrack-Analyse` und die benachbarten Konzepte wird jeweils (a) die Definition aus der konkreten musikalischen oder technischen Perspektive, (b) Ein- und Ausgangsdaten, (c) ein realistischer Hör- oder Editierkontext, (d) typische Grenzfälle, (e) mögliche Export-/Lizenzrestriktionen und (f) ein prüfbarer Gegenfall benötigt. Nicht jedes benannte Thema ist im vorliegenden Dossier schon vollständig erarbeitet.

**STEPS-Umsetzung:** Das Cluster erhält separat versionierbare Skills bzw. Lernkarten. Eine konkrete STEPS-Funktion wird nur dann implementiert, wenn sie sich aus vorhandenen Daten, Instrumenten- oder Clip-Informationen ableiten lässt. Bei reiner Hör-/Stilbeurteilung ist der Test ein menschlicher Hörvergleich, keine binäre Software-Assertion.

### Themencluster 3: Zeitbudget, Rollen und Zuständigkeiten, Style Guide, Song Map, Tempo und Tonart

**Was zu dokumentieren ist:** Für `Zeitbudget` und die benachbarten Konzepte wird jeweils (a) die Definition aus der konkreten musikalischen oder technischen Perspektive, (b) Ein- und Ausgangsdaten, (c) ein realistischer Hör- oder Editierkontext, (d) typische Grenzfälle, (e) mögliche Export-/Lizenzrestriktionen und (f) ein prüfbarer Gegenfall benötigt. Nicht jedes benannte Thema ist im vorliegenden Dossier schon vollständig erarbeitet.

**STEPS-Umsetzung:** Das Cluster erhält separat versionierbare Skills bzw. Lernkarten. Eine konkrete STEPS-Funktion wird nur dann implementiert, wenn sie sich aus vorhandenen Daten, Instrumenten- oder Clip-Informationen ableiten lässt. Bei reiner Hör-/Stilbeurteilung ist der Test ein menschlicher Hörvergleich, keine binäre Software-Assertion.

### Themencluster 4: Emotional Arc, Preproduction-Rehearsal, Demo Selection, Revision Budget, Definition of Done

**Was zu dokumentieren ist:** Für `Emotional Arc` und die benachbarten Konzepte wird jeweils (a) die Definition aus der konkreten musikalischen oder technischen Perspektive, (b) Ein- und Ausgangsdaten, (c) ein realistischer Hör- oder Editierkontext, (d) typische Grenzfälle, (e) mögliche Export-/Lizenzrestriktionen und (f) ein prüfbarer Gegenfall benötigt. Nicht jedes benannte Thema ist im vorliegenden Dossier schon vollständig erarbeitet.

**STEPS-Umsetzung:** Das Cluster erhält separat versionierbare Skills bzw. Lernkarten. Eine konkrete STEPS-Funktion wird nur dann implementiert, wenn sie sich aus vorhandenen Daten, Instrumenten- oder Clip-Informationen ableiten lässt. Bei reiner Hör-/Stilbeurteilung ist der Test ein menschlicher Hörvergleich, keine binäre Software-Assertion.

### Themencluster 5: Entscheidungsprotokoll, Abnahme mit Künstler

**Was zu dokumentieren ist:** Für `Entscheidungsprotokoll` und die benachbarten Konzepte wird jeweils (a) die Definition aus der konkreten musikalischen oder technischen Perspektive, (b) Ein- und Ausgangsdaten, (c) ein realistischer Hör- oder Editierkontext, (d) typische Grenzfälle, (e) mögliche Export-/Lizenzrestriktionen und (f) ein prüfbarer Gegenfall benötigt. Nicht jedes benannte Thema ist im vorliegenden Dossier schon vollständig erarbeitet.

**STEPS-Umsetzung:** Das Cluster erhält separat versionierbare Skills bzw. Lernkarten. Eine konkrete STEPS-Funktion wird nur dann implementiert, wenn sie sich aus vorhandenen Daten, Instrumenten- oder Clip-Informationen ableiten lässt. Bei reiner Hör-/Stilbeurteilung ist der Test ein menschlicher Hörvergleich, keine binäre Software-Assertion.


## Lernpfad
**Einsteiger:** Identifiziere die relevanten Objekte, Signale und musikalischen Rollen ohne Spezialsoftware.  
**Fortgeschritten:** Baue zwei absichtlich kontrastierende Versionen und beschreibe ihre Konsequenzen.  
**Experten:** Dokumentiere den Grenzfall, einen Gegenbeleg und den Export in eine andere DAW / ein neues Wiedergabesystem.

## Daten- und Quellenpflicht
Jeder spätere atomare Wissenseintrag braucht `source_id`, `claim_type`, `confidence`, `review_status`, `license_status`, `tool_assumptions` und nach Möglichkeit eine `golden_test_id`. Ein Quellenlink in einem Sammelregister ersetzt keine Einzelclaim-Zitation. Berücksichtige dokumentierte Hersteller- und Standardunterschiede; stelle allgemeine Producing-Tipps nicht als universelle Standards dar.

## Codex-Abnahme (nur als Forschungsdatenbank)
- [ ] Eigene Domain-/Subtopic-IDs sind stabil und in der Taxonomie auffindbar.
- [ ] Jede eingeführte Softwarefunktion benennt Ein- und Ausgabe inklusive Fehlerfällen.
- [ ] Neue Quellenbelege sind einzeln nachvollziehbar, nicht nur thematisch genannt.
- [ ] Geschützte Tonaufnahmen und Presets werden nicht automatisch in ein öffentliches Projekt übertragen.
- [ ] Wahrnehmung und Stil werden qualitativ geprüft; technische Datenschemata automatisch.

## Fachbegriffe (indexiert; kein vollständiges Lehrbuch)
Creative Brief, Produzentenrolle, Artist Identity, Zielgruppe, Musikalische Intention, Referenztrack-Analyse, Moodboard, Demo und Skizze, Kreative Beschränkungen, Scope, Zeitbudget, Rollen und Zuständigkeiten, Style Guide, Song Map, Tempo und Tonart, Emotional Arc, Preproduction-Rehearsal, Demo Selection, Revision Budget, Definition of Done, Entscheidungsprotokoll, Abnahme mit Künstler.
