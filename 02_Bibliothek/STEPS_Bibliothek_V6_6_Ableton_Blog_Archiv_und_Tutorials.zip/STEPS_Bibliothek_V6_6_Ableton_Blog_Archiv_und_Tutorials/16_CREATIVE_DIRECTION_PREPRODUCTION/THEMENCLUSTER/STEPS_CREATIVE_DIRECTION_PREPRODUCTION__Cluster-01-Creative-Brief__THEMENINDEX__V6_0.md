# Creative Direction, Ideation & Pre-Production — Themencluster 1

**Status:** Taxonomische Arbeitsdatei; wissenschaftliche Einzelquellenprüfung ausstehend.

## Begriffe und Anforderungen
### Creative Brief
- Rolle im Bereich: `Creative Direction, Ideation & Pre-Production`; Eingabeobjekte, Fachdefinition und Audio-/MIDI-Wirkung müssen bei der Vertiefung explizit bestimmt werden.
- Praxisfrage: Welchen hörbaren oder editierbaren Unterschied macht **Creative Brief** im Vergleich zur unveränderten Ausgangsversion?
- Prüfvorschlag: kontrollierter A/B-Vergleich, dokumentiertes Quellenprotokoll, ein Gegenbeispiel und ein eindeutiger Export-/Lizenzstatus.
- Reifegrad: **indexiert, nicht vollständig fachlich validiert**.

### Produzentenrolle
- Rolle im Bereich: `Creative Direction, Ideation & Pre-Production`; Eingabeobjekte, Fachdefinition und Audio-/MIDI-Wirkung müssen bei der Vertiefung explizit bestimmt werden.
- Praxisfrage: Welchen hörbaren oder editierbaren Unterschied macht **Produzentenrolle** im Vergleich zur unveränderten Ausgangsversion?
- Prüfvorschlag: kontrollierter A/B-Vergleich, dokumentiertes Quellenprotokoll, ein Gegenbeispiel und ein eindeutiger Export-/Lizenzstatus.
- Reifegrad: **indexiert, nicht vollständig fachlich validiert**.

### Artist Identity
- Rolle im Bereich: `Creative Direction, Ideation & Pre-Production`; Eingabeobjekte, Fachdefinition und Audio-/MIDI-Wirkung müssen bei der Vertiefung explizit bestimmt werden.
- Praxisfrage: Welchen hörbaren oder editierbaren Unterschied macht **Artist Identity** im Vergleich zur unveränderten Ausgangsversion?
- Prüfvorschlag: kontrollierter A/B-Vergleich, dokumentiertes Quellenprotokoll, ein Gegenbeispiel und ein eindeutiger Export-/Lizenzstatus.
- Reifegrad: **indexiert, nicht vollständig fachlich validiert**.

### Zielgruppe
- Rolle im Bereich: `Creative Direction, Ideation & Pre-Production`; Eingabeobjekte, Fachdefinition und Audio-/MIDI-Wirkung müssen bei der Vertiefung explizit bestimmt werden.
- Praxisfrage: Welchen hörbaren oder editierbaren Unterschied macht **Zielgruppe** im Vergleich zur unveränderten Ausgangsversion?
- Prüfvorschlag: kontrollierter A/B-Vergleich, dokumentiertes Quellenprotokoll, ein Gegenbeispiel und ein eindeutiger Export-/Lizenzstatus.
- Reifegrad: **indexiert, nicht vollständig fachlich validiert**.

### Musikalische Intention
- Rolle im Bereich: `Creative Direction, Ideation & Pre-Production`; Eingabeobjekte, Fachdefinition und Audio-/MIDI-Wirkung müssen bei der Vertiefung explizit bestimmt werden.
- Praxisfrage: Welchen hörbaren oder editierbaren Unterschied macht **Musikalische Intention** im Vergleich zur unveränderten Ausgangsversion?
- Prüfvorschlag: kontrollierter A/B-Vergleich, dokumentiertes Quellenprotokoll, ein Gegenbeispiel und ein eindeutiger Export-/Lizenzstatus.
- Reifegrad: **indexiert, nicht vollständig fachlich validiert**.

## Nächster Nachweis
Für jeden Begriff eine Primärquelle oder offizielle Tooldokumentation, eine Quellenfundstelle, original erzeugtes Beispiel und manuelles Review ergänzen.
