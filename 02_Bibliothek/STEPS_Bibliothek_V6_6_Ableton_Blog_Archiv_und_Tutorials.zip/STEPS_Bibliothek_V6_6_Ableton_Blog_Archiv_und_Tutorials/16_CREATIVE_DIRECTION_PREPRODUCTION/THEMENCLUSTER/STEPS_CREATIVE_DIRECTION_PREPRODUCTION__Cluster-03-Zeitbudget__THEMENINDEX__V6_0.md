# Creative Direction, Ideation & Pre-Production — Themencluster 3

**Status:** Taxonomische Arbeitsdatei; wissenschaftliche Einzelquellenprüfung ausstehend.

## Begriffe und Anforderungen
### Zeitbudget
- Rolle im Bereich: `Creative Direction, Ideation & Pre-Production`; Eingabeobjekte, Fachdefinition und Audio-/MIDI-Wirkung müssen bei der Vertiefung explizit bestimmt werden.
- Praxisfrage: Welchen hörbaren oder editierbaren Unterschied macht **Zeitbudget** im Vergleich zur unveränderten Ausgangsversion?
- Prüfvorschlag: kontrollierter A/B-Vergleich, dokumentiertes Quellenprotokoll, ein Gegenbeispiel und ein eindeutiger Export-/Lizenzstatus.
- Reifegrad: **indexiert, nicht vollständig fachlich validiert**.

### Rollen und Zuständigkeiten
- Rolle im Bereich: `Creative Direction, Ideation & Pre-Production`; Eingabeobjekte, Fachdefinition und Audio-/MIDI-Wirkung müssen bei der Vertiefung explizit bestimmt werden.
- Praxisfrage: Welchen hörbaren oder editierbaren Unterschied macht **Rollen und Zuständigkeiten** im Vergleich zur unveränderten Ausgangsversion?
- Prüfvorschlag: kontrollierter A/B-Vergleich, dokumentiertes Quellenprotokoll, ein Gegenbeispiel und ein eindeutiger Export-/Lizenzstatus.
- Reifegrad: **indexiert, nicht vollständig fachlich validiert**.

### Style Guide
- Rolle im Bereich: `Creative Direction, Ideation & Pre-Production`; Eingabeobjekte, Fachdefinition und Audio-/MIDI-Wirkung müssen bei der Vertiefung explizit bestimmt werden.
- Praxisfrage: Welchen hörbaren oder editierbaren Unterschied macht **Style Guide** im Vergleich zur unveränderten Ausgangsversion?
- Prüfvorschlag: kontrollierter A/B-Vergleich, dokumentiertes Quellenprotokoll, ein Gegenbeispiel und ein eindeutiger Export-/Lizenzstatus.
- Reifegrad: **indexiert, nicht vollständig fachlich validiert**.

### Song Map
- Rolle im Bereich: `Creative Direction, Ideation & Pre-Production`; Eingabeobjekte, Fachdefinition und Audio-/MIDI-Wirkung müssen bei der Vertiefung explizit bestimmt werden.
- Praxisfrage: Welchen hörbaren oder editierbaren Unterschied macht **Song Map** im Vergleich zur unveränderten Ausgangsversion?
- Prüfvorschlag: kontrollierter A/B-Vergleich, dokumentiertes Quellenprotokoll, ein Gegenbeispiel und ein eindeutiger Export-/Lizenzstatus.
- Reifegrad: **indexiert, nicht vollständig fachlich validiert**.

### Tempo und Tonart
- Rolle im Bereich: `Creative Direction, Ideation & Pre-Production`; Eingabeobjekte, Fachdefinition und Audio-/MIDI-Wirkung müssen bei der Vertiefung explizit bestimmt werden.
- Praxisfrage: Welchen hörbaren oder editierbaren Unterschied macht **Tempo und Tonart** im Vergleich zur unveränderten Ausgangsversion?
- Prüfvorschlag: kontrollierter A/B-Vergleich, dokumentiertes Quellenprotokoll, ein Gegenbeispiel und ein eindeutiger Export-/Lizenzstatus.
- Reifegrad: **indexiert, nicht vollständig fachlich validiert**.

## Nächster Nachweis
Für jeden Begriff eine Primärquelle oder offizielle Tooldokumentation, eine Quellenfundstelle, original erzeugtes Beispiel und manuelles Review ergänzen.
