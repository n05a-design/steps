# Creative Direction, Ideation & Pre-Production — Themencluster 2

**Status:** Taxonomische Arbeitsdatei; wissenschaftliche Einzelquellenprüfung ausstehend.

## Begriffe und Anforderungen
### Referenztrack-Analyse
- Rolle im Bereich: `Creative Direction, Ideation & Pre-Production`; Eingabeobjekte, Fachdefinition und Audio-/MIDI-Wirkung müssen bei der Vertiefung explizit bestimmt werden.
- Praxisfrage: Welchen hörbaren oder editierbaren Unterschied macht **Referenztrack-Analyse** im Vergleich zur unveränderten Ausgangsversion?
- Prüfvorschlag: kontrollierter A/B-Vergleich, dokumentiertes Quellenprotokoll, ein Gegenbeispiel und ein eindeutiger Export-/Lizenzstatus.
- Reifegrad: **indexiert, nicht vollständig fachlich validiert**.

### Moodboard
- Rolle im Bereich: `Creative Direction, Ideation & Pre-Production`; Eingabeobjekte, Fachdefinition und Audio-/MIDI-Wirkung müssen bei der Vertiefung explizit bestimmt werden.
- Praxisfrage: Welchen hörbaren oder editierbaren Unterschied macht **Moodboard** im Vergleich zur unveränderten Ausgangsversion?
- Prüfvorschlag: kontrollierter A/B-Vergleich, dokumentiertes Quellenprotokoll, ein Gegenbeispiel und ein eindeutiger Export-/Lizenzstatus.
- Reifegrad: **indexiert, nicht vollständig fachlich validiert**.

### Demo und Skizze
- Rolle im Bereich: `Creative Direction, Ideation & Pre-Production`; Eingabeobjekte, Fachdefinition und Audio-/MIDI-Wirkung müssen bei der Vertiefung explizit bestimmt werden.
- Praxisfrage: Welchen hörbaren oder editierbaren Unterschied macht **Demo und Skizze** im Vergleich zur unveränderten Ausgangsversion?
- Prüfvorschlag: kontrollierter A/B-Vergleich, dokumentiertes Quellenprotokoll, ein Gegenbeispiel und ein eindeutiger Export-/Lizenzstatus.
- Reifegrad: **indexiert, nicht vollständig fachlich validiert**.

### Kreative Beschränkungen
- Rolle im Bereich: `Creative Direction, Ideation & Pre-Production`; Eingabeobjekte, Fachdefinition und Audio-/MIDI-Wirkung müssen bei der Vertiefung explizit bestimmt werden.
- Praxisfrage: Welchen hörbaren oder editierbaren Unterschied macht **Kreative Beschränkungen** im Vergleich zur unveränderten Ausgangsversion?
- Prüfvorschlag: kontrollierter A/B-Vergleich, dokumentiertes Quellenprotokoll, ein Gegenbeispiel und ein eindeutiger Export-/Lizenzstatus.
- Reifegrad: **indexiert, nicht vollständig fachlich validiert**.

### Scope
- Rolle im Bereich: `Creative Direction, Ideation & Pre-Production`; Eingabeobjekte, Fachdefinition und Audio-/MIDI-Wirkung müssen bei der Vertiefung explizit bestimmt werden.
- Praxisfrage: Welchen hörbaren oder editierbaren Unterschied macht **Scope** im Vergleich zur unveränderten Ausgangsversion?
- Prüfvorschlag: kontrollierter A/B-Vergleich, dokumentiertes Quellenprotokoll, ein Gegenbeispiel und ein eindeutiger Export-/Lizenzstatus.
- Reifegrad: **indexiert, nicht vollständig fachlich validiert**.

## Nächster Nachweis
Für jeden Begriff eine Primärquelle oder offizielle Tooldokumentation, eine Quellenfundstelle, original erzeugtes Beispiel und manuelles Review ergänzen.
