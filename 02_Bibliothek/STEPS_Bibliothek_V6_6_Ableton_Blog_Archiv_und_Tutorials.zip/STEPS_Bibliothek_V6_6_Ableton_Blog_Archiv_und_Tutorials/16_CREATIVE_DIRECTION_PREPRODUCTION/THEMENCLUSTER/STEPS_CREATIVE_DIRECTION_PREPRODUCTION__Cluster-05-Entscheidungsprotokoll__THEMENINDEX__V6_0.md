# Creative Direction, Ideation & Pre-Production — Themencluster 5

**Status:** Taxonomische Arbeitsdatei; wissenschaftliche Einzelquellenprüfung ausstehend.

## Begriffe und Anforderungen
### Entscheidungsprotokoll
- Rolle im Bereich: `Creative Direction, Ideation & Pre-Production`; Eingabeobjekte, Fachdefinition und Audio-/MIDI-Wirkung müssen bei der Vertiefung explizit bestimmt werden.
- Praxisfrage: Welchen hörbaren oder editierbaren Unterschied macht **Entscheidungsprotokoll** im Vergleich zur unveränderten Ausgangsversion?
- Prüfvorschlag: kontrollierter A/B-Vergleich, dokumentiertes Quellenprotokoll, ein Gegenbeispiel und ein eindeutiger Export-/Lizenzstatus.
- Reifegrad: **indexiert, nicht vollständig fachlich validiert**.

### Abnahme mit Künstler
- Rolle im Bereich: `Creative Direction, Ideation & Pre-Production`; Eingabeobjekte, Fachdefinition und Audio-/MIDI-Wirkung müssen bei der Vertiefung explizit bestimmt werden.
- Praxisfrage: Welchen hörbaren oder editierbaren Unterschied macht **Abnahme mit Künstler** im Vergleich zur unveränderten Ausgangsversion?
- Prüfvorschlag: kontrollierter A/B-Vergleich, dokumentiertes Quellenprotokoll, ein Gegenbeispiel und ein eindeutiger Export-/Lizenzstatus.
- Reifegrad: **indexiert, nicht vollständig fachlich validiert**.

## Nächster Nachweis
Für jeden Begriff eine Primärquelle oder offizielle Tooldokumentation, eine Quellenfundstelle, original erzeugtes Beispiel und manuelles Review ergänzen.
