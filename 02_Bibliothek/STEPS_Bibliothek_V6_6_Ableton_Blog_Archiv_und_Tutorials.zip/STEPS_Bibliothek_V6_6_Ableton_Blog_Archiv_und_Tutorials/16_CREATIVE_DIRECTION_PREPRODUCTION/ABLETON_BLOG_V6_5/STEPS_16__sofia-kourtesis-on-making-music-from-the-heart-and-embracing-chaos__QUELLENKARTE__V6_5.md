# ABLETON-177 | Sofia Kourtesis on Making Music from the Heart and Embracing Chaos

**Quelle:** [Ableton Originalbeitrag](https://www.ableton.com/en/blog/sofia-kourtesis-on-making-music-from-the-heart-and-embracing-chaos/)  
**Forschungsstatus:** Artikel-Webseite geöffnet und Titel/Themenkontext überprüft; eingebettete Videos/Podcasts nicht vollständig angehört/transkribiert.  
**Quellentyp:** Podcast  
**STEPS-Hauptbereich:** `16_CREATIVE_DIRECTION_PREPRODUCTION`  
**Stichworte:** House;Field Recording;Creative Intent  
**Quellenbeleg (Sitzung):** `turn968294view12` – der Link oben ist der dauerhafte Nachweis.  
**Assets/Rechte:** Kein Download aus dieser Untersuchung übernommen; kein Beitragstext, Sound, Sample, Video oder Projektdatei im STEPS-Archiv reproduziert.

## Relevanz für STEPS

Emotionale Konzeptideen in Soundauswahl und Arrangemententwicklung übersetzen.

## Eigenständiger Forschungs- und Übungsauftrag

1. **Beobachtung:** Erstelle ein neues, eigenständig produziertes Beispiel, das *eine* Technik aus dem Themenkomplex `House` untersucht. Dokumentiere musikalisches Ziel, Genre-Kontext und Parameter, nicht bloß Produktnamen.
2. **Kontrollvergleich:** Erstelle eine A/B-Version, bei der die untersuchte Variable geändert wird, während Tempo, Lautheit und übriges Arrangement soweit möglich konstant bleiben.
3. **Analyse:** Trenne automatisch nachprüfbare Eigenschaften (Notenanzahl, Taktlänge, Timing, Dateiformat) von musikalischen und wahrnehmungsbezogenen Urteilen (Feel, Ausdruck, Wiedererkennbarkeit).
4. **Codex-Übernahme:** Nur das eigenständige Lehrbeispiel, ein Quellverweis, seine methodischen Grenzen und konkrete Tests dürfen in die öffentliche Wissensbasis eingehen. Originalassets bleiben außerhalb davon.

## Prüfstatus / Grenzen

- [x] Offizielle URL aufgerufen und Hauptthema gefunden.
- [x] Themenzuordnung und STEPS-Transfer eigenständig formuliert.
- [ ] Eingebettetes Video bzw. Podcast vollständig angesehen/gehört.
- [ ] Konkrete Geräteeinstellungen und Ergebnisse reproduziert.
- [ ] Eventuelle Sample-/Projektlizenzen direkt einzeln geprüft.
- [ ] Fachlich und auditiv durch Reviewer abgenommen.

*Die STEPS-Übung ist eine neu formulierte Forschungsaufgabe, keine Wiedergabe der bezahlten oder urheberrechtlich geschützten Quelle.*
