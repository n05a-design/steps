# Horse Lords: Inside Their Microtonal Universe — STEPS-Quellenkarte V6.4

**Dokument-ID:** `ABLETON-099` · **Stand:** 2026-11-09 · **Fachbereich:** `01_MUSIKTHEORIE`  
**Originalartikel:** https://www.ableton.com/en/blog/horse-lords-inside-their-microtonal-universe/  
**Stichwörter:** Just Intonation;Microtonality;Counterpoint;Composition  
**Typ:** Interview · **Verifikation:** `article_page_opened` (Original-Webseite oder offizielles Suchergebnis; keine vollständige audiovisuelle Begutachtung)

## Warum diese Quelle in STEPS steht

Praxisblick auf alternative Stimmungen, polyrhythmisches Ensemblespiel und kollaboratives Komponieren; verschiedene Stimmungsmodelle getrennt halten.

## Fachliche Einordnung und Grenzen

- **Direkter Quellenkontext:** Ableton-Artikel oder Künstlergespräch. Es ist keine externe wissenschaftliche Qualitätsbegutachtung.
- **Transferidee / Eigenleistung:** Notations-/Stimmungsmodell — A/B-Beispiel in mindestens zwei Stimmsystemen; Töne und Intervalle mit Systemkontext darstellen.
- **Gegenprüfung:** Alternative Temperamente nicht als bloße Transposition mit 12-TET behandeln.
- **Verknüpfung:** Fachbereich `01_MUSIKTHEORIE` und übergreifendes Quellenregister in `10_QUELLEN_LIZENZEN`.

## Was Codex damit tun soll

1. Link und Veröffentlichungsdatum erneut prüfen; falls der Artikel auf eine ältere Live-Version verweist, Release-Versionsbezug markieren.
2. Aus dem Original nur eigenständig beschriebene Begriffe, überprüfbare Schritte und eigene Beispiele in die STEPS-KB übernehmen; jede konkrete Behauptung mit Link und Abschnitt versehen.
3. Künstlerzitate/ästhetische Vorlieben als individuelle Aussagen kennzeichnen; niemals universell gültige Musikregeln ableiten.
4. Das oben vorgeschlagene Experiment mit **eigenen Noten, MIDI- und Audioartefakten** ausarbeiten und Hör-/Techniktest protokollieren.
5. Bei Assets Lizenz und Rechte individuell prüfen, bevor Dateien gespeichert, als Trainingsdaten verwendet oder veröffentlicht werden.

## Asset- und Qualitätsstatus

- Asset-Hinweis: `samples` / `asset_link_not_downloaded`.
- Wiedergabe des Originalartikels: **nicht enthalten**.
- Download, Lizenz, konkrete Nutzungsrechte: **nicht freigegeben** ohne separate Prüfung.
- Fachlicher Volltextreview, Video-/Audioanalyse und Tests im STEPS-Repo: **ausstehend**.
