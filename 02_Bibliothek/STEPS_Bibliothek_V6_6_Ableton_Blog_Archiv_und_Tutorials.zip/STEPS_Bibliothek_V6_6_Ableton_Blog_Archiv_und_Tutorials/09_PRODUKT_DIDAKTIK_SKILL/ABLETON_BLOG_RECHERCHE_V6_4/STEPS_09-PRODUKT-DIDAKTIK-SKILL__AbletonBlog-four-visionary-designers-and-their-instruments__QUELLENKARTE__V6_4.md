# Four Visionary Designers and Their Instruments — STEPS-Quellenkarte V6.4

**Dokument-ID:** `ABLETON-148` · **Stand:** 2026-11-09 · **Fachbereich:** `09_PRODUKT_DIDAKTIK_SKILL`  
**Originalartikel:** https://www.ableton.com/en/blog/visionary-designers-and-their-instruments/  
**Stichwörter:** Instrument Design;Interaction;Creativity;HCI  
**Typ:** Feature · **Verifikation:** `article_page_opened` (Original-Webseite oder offizielles Suchergebnis; keine vollständige audiovisuelle Begutachtung)

## Warum diese Quelle in STEPS steht

Gespräch über experimentelle Instrumenten-Interfaces und Gestaltungsphilosophien.

## Fachliche Einordnung und Grenzen

- **Direkter Quellenkontext:** Ableton-Artikel oder Künstlergespräch. Es ist keine externe wissenschaftliche Qualitätsbegutachtung.
- **Transferidee / Eigenleistung:** Didaktik-Transfer — Lernziel, Interaktion, Fehlerzustand und Audio-/MIDI-Lernbeispiel entwerfen.
- **Gegenprüfung:** Historische Geräteentscheidungen nicht ungeprüft als UX-Norm übernehmen.
- **Verknüpfung:** Fachbereich `09_PRODUKT_DIDAKTIK_SKILL` und übergreifendes Quellenregister in `10_QUELLEN_LIZENZEN`.

## Was Codex damit tun soll

1. Link und Veröffentlichungsdatum erneut prüfen; falls der Artikel auf eine ältere Live-Version verweist, Release-Versionsbezug markieren.
2. Aus dem Original nur eigenständig beschriebene Begriffe, überprüfbare Schritte und eigene Beispiele in die STEPS-KB übernehmen; jede konkrete Behauptung mit Link und Abschnitt versehen.
3. Künstlerzitate/ästhetische Vorlieben als individuelle Aussagen kennzeichnen; niemals universell gültige Musikregeln ableiten.
4. Das oben vorgeschlagene Experiment mit **eigenen Noten, MIDI- und Audioartefakten** ausarbeiten und Hör-/Techniktest protokollieren.
5. Bei Assets Lizenz und Rechte individuell prüfen, bevor Dateien gespeichert, als Trainingsdaten verwendet oder veröffentlicht werden.

## Asset- und Qualitätsstatus

- Asset-Hinweis: `none` / `no_asset_claim_in_this_study`.
- Wiedergabe des Originalartikels: **nicht enthalten**.
- Download, Lizenz, konkrete Nutzungsrechte: **nicht freigegeben** ohne separate Prüfung.
- Fachlicher Volltextreview, Video-/Audioanalyse und Tests im STEPS-Repo: **ausstehend**.
