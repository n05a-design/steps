# Progressionsfall P17: backdoor_jazz

**Ton-/Modalitätshypothese:** C major. **Tempo:** 124 BPM. **Takt:** 4/4. **Originale didaktische Konstruktion**, keine Transkription oder statistische Norm.

## Spielbare Kurzform
`| Dm7 | Bb7 | Cmaj7 | Cmaj7 |` – jeweils ein Akkord pro Takt mit vier Vierteln, ausdrücklich modifizierbar.

**Analyse-Lens:** `ii–bVII7–Imaj7`. Der Roman-Numeral-String ist eine didaktische Lesart, nicht ein formatvalidierter DCML-Export.

**Klangliche Hypothese:** Backdoor cadential suggestion, stylistic dependent.

## Konkrete Werkstattentscheidung
Compare Bb7 with G7 over same top melody. Probiere für die vier Takte eine Oberstimme und eine Bassbewegung; halte das Akkordschema konstant und variiere anschließend ausschließlich die Dauer der Akkorde.

## Gegenfragen / Falsifikation
- Ist die vermutete Tonika wirklich in Melodie, Bass und Form bestätigt oder nur aus der Akkordfolge geraten?
- Sind die angegebenen Akkorde mit der tatsächlichen Hüllkurve der Instrumente kompatibel?
- Gibt es eine zweite plausible Interpretation in einer anderen Stilhörweise?

## Maschinenprüfbarkeit
Die parallele Datei `STEPS_PROGRESSIONS__V5_4-Originale-Progressionsfaelle__DATEN__V5_4.json` enthält Grundton, Bass, diatonisches Symbol und Pitch-Class-Mengen. Der musikalische Analyse-Lens bleibt offen für Review.
