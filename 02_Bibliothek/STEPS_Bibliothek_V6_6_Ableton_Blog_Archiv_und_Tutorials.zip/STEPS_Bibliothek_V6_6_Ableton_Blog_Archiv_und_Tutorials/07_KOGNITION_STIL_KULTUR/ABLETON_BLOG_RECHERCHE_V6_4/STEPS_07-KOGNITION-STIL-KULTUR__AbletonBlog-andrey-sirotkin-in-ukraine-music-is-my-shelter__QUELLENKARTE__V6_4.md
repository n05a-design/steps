# Andrey Sirotkin: In Ukraine, Music Is My Shelter — STEPS-Quellenkarte V6.4

**Dokument-ID:** `ABLETON-134` · **Stand:** 2026-11-09 · **Fachbereich:** `07_KOGNITION_STIL_KULTUR`  
**Originalartikel:** https://www.ableton.com/en/blog/andrey-sirotkin-in-ukraine-music-is-my-shelter/  
**Stichwörter:** Creative Resilience;Techno;Collaboration;Context  
**Typ:** Interview · **Verifikation:** `article_page_opened` (Original-Webseite oder offizielles Suchergebnis; keine vollständige audiovisuelle Begutachtung)

## Warum diese Quelle in STEPS steht

Künstlerisches Arbeiten unter schwierigen Bedingungen; Kontext respektieren und nicht als Standard-Produktionsmethode verallgemeinern.

## Fachliche Einordnung und Grenzen

- **Direkter Quellenkontext:** Ableton-Artikel oder Künstlergespräch. Es ist keine externe wissenschaftliche Qualitätsbegutachtung.
- **Transferidee / Eigenleistung:** Musikpsychologie-Kontext — Autorenbeobachtung, belegbare Aussage und Hypothese als verschiedene Ebenen markieren.
- **Gegenprüfung:** Ein einzelnes Interview ist kein empirischer Nachweis.
- **Verknüpfung:** Fachbereich `07_KOGNITION_STIL_KULTUR` und übergreifendes Quellenregister in `10_QUELLEN_LIZENZEN`.

## Was Codex damit tun soll

1. Link und Veröffentlichungsdatum erneut prüfen; falls der Artikel auf eine ältere Live-Version verweist, Release-Versionsbezug markieren.
2. Aus dem Original nur eigenständig beschriebene Begriffe, überprüfbare Schritte und eigene Beispiele in die STEPS-KB übernehmen; jede konkrete Behauptung mit Link und Abschnitt versehen.
3. Künstlerzitate/ästhetische Vorlieben als individuelle Aussagen kennzeichnen; niemals universell gültige Musikregeln ableiten.
4. Das oben vorgeschlagene Experiment mit **eigenen Noten, MIDI- und Audioartefakten** ausarbeiten und Hör-/Techniktest protokollieren.
5. Bei Assets Lizenz und Rechte individuell prüfen, bevor Dateien gespeichert, als Trainingsdaten verwendet oder veröffentlicht werden.

## Asset- und Qualitätsstatus

- Asset-Hinweis: `none` / `no_asset_claim_in_this_study`.
- Wiedergabe des Originalartikels: **nicht enthalten**.
- Download, Lizenz, konkrete Nutzungsrechte: **nicht freigegeben** ohne separate Prüfung.
- Fachlicher Volltextreview, Video-/Audioanalyse und Tests im STEPS-Repo: **ausstehend**.
