# Granularsynthese und Klangform – vertiefte STEPS-Transferstudie

**Artikel:** [Against the Grain: Creative Applications of Granulator III](https://www.ableton.com/en/blog/against-the-grain-creative-applications-of-granulator-iii/) · `ABLETON-114` · Quellenstatus `official_search_result_verified`

## Quellenbeobachtung

Der Tutorial-Teaser beschreibt Experimente aus einer Sprachaufnahme mit Granularparametern, Grain Size und Spread. Einzelparameter-Wirkungen müssen in einer eigenen DAW-Umgebung überprüft werden.

## Neue STEPS-Eigenübung

Nimm einen eigenen kurzen Sprachlaut auf und erzeuge drei Varianten mit dokumentiertem Startpunkt, Grain Size, Spread und FX Chain. Prüfe Mono-Kompatibilität.

## Negative Abnahme / Kontextgrenze

Eine breitere Stereowahrnehmung ist kein Nachweis für gute Monoübersetzung.

## Prüfroutine

1. Eigenes Ausgangsmaterial und Version erfassen.
2. Ereignisse oder Audioparameter maschinenlesbar ablegen.
3. Reproduzierbarkeit und technische Bedingungen prüfen.
4. Hörreview und kontextabhängige ästhetische Bewertung getrennt dokumentieren.
5. Quellen- und Lizenzstatus nicht ohne Einzelprüfung hochstufen.
