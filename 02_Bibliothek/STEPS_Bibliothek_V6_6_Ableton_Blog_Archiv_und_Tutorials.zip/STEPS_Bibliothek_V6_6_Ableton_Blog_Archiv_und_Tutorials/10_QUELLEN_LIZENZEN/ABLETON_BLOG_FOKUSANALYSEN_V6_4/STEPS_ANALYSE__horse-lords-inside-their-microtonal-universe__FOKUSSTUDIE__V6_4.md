# Mikrotonalität und Zusammenarbeit – vertiefte STEPS-Transferstudie

**Artikel:** [Horse Lords: Inside Their Microtonal Universe](https://www.ableton.com/en/blog/horse-lords-inside-their-microtonal-universe/) · `ABLETON-099` · Quellenstatus `article_page_opened`

## Quellenbeobachtung

Die Band diskutiert Just Intonation, musikalischen Kontrapunkt und die Nutzung von Abletons Unterstützung alternativer Stimmungssysteme. Das Interview liefert eine dokumentierte künstlerische Praxis, aber keinen mathematischen Beweis für ein bestimmtes Tonnetz.

## Neue STEPS-Eigenübung

Erzeuge ein eigenes 4-Takt-Motiv in 12-TET und in frei ausgewählter reiner Stimmung. Speichere je Ton Frequenz, Cent-Abweichung, Stimmungskontext und MIDI-Referenz. Vergleiche nicht nur Pitch Classes, sondern konkrete Frequenzen.

## Negative Abnahme / Kontextgrenze

Transposition ohne Stimmungsspezifikation darf nicht stillschweigend alle Frequenzrelationen als gleich behandeln.

## Prüfroutine

1. Eigenes Ausgangsmaterial und Version erfassen.
2. Ereignisse oder Audioparameter maschinenlesbar ablegen.
3. Reproduzierbarkeit und technische Bedingungen prüfen.
4. Hörreview und kontextabhängige ästhetische Bewertung getrennt dokumentieren.
5. Quellen- und Lizenzstatus nicht ohne Einzelprüfung hochstufen.
