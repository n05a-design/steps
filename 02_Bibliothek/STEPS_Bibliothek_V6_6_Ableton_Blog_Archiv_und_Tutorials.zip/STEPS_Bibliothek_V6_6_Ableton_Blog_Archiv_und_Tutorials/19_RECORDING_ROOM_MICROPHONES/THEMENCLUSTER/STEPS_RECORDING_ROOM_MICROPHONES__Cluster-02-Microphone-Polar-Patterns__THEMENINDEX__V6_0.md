# Recording, Room Acoustics & Microphone Technique — Themencluster 2

**Status:** Taxonomische Arbeitsdatei; wissenschaftliche Einzelquellenprüfung ausstehend.

## Begriffe und Anforderungen
### Microphone Polar Patterns
- Rolle im Bereich: `Recording, Room Acoustics & Microphone Technique`; Eingabeobjekte, Fachdefinition und Audio-/MIDI-Wirkung müssen bei der Vertiefung explizit bestimmt werden.
- Praxisfrage: Welchen hörbaren oder editierbaren Unterschied macht **Microphone Polar Patterns** im Vergleich zur unveränderten Ausgangsversion?
- Prüfvorschlag: kontrollierter A/B-Vergleich, dokumentiertes Quellenprotokoll, ein Gegenbeispiel und ein eindeutiger Export-/Lizenzstatus.
- Reifegrad: **indexiert, nicht vollständig fachlich validiert**.

### Dynamic Microphone
- Rolle im Bereich: `Recording, Room Acoustics & Microphone Technique`; Eingabeobjekte, Fachdefinition und Audio-/MIDI-Wirkung müssen bei der Vertiefung explizit bestimmt werden.
- Praxisfrage: Welchen hörbaren oder editierbaren Unterschied macht **Dynamic Microphone** im Vergleich zur unveränderten Ausgangsversion?
- Prüfvorschlag: kontrollierter A/B-Vergleich, dokumentiertes Quellenprotokoll, ein Gegenbeispiel und ein eindeutiger Export-/Lizenzstatus.
- Reifegrad: **indexiert, nicht vollständig fachlich validiert**.

### Condenser Microphone
- Rolle im Bereich: `Recording, Room Acoustics & Microphone Technique`; Eingabeobjekte, Fachdefinition und Audio-/MIDI-Wirkung müssen bei der Vertiefung explizit bestimmt werden.
- Praxisfrage: Welchen hörbaren oder editierbaren Unterschied macht **Condenser Microphone** im Vergleich zur unveränderten Ausgangsversion?
- Prüfvorschlag: kontrollierter A/B-Vergleich, dokumentiertes Quellenprotokoll, ein Gegenbeispiel und ein eindeutiger Export-/Lizenzstatus.
- Reifegrad: **indexiert, nicht vollständig fachlich validiert**.

### Ribbon Microphone
- Rolle im Bereich: `Recording, Room Acoustics & Microphone Technique`; Eingabeobjekte, Fachdefinition und Audio-/MIDI-Wirkung müssen bei der Vertiefung explizit bestimmt werden.
- Praxisfrage: Welchen hörbaren oder editierbaren Unterschied macht **Ribbon Microphone** im Vergleich zur unveränderten Ausgangsversion?
- Prüfvorschlag: kontrollierter A/B-Vergleich, dokumentiertes Quellenprotokoll, ein Gegenbeispiel und ein eindeutiger Export-/Lizenzstatus.
- Reifegrad: **indexiert, nicht vollständig fachlich validiert**.

### Proximity Effect
- Rolle im Bereich: `Recording, Room Acoustics & Microphone Technique`; Eingabeobjekte, Fachdefinition und Audio-/MIDI-Wirkung müssen bei der Vertiefung explizit bestimmt werden.
- Praxisfrage: Welchen hörbaren oder editierbaren Unterschied macht **Proximity Effect** im Vergleich zur unveränderten Ausgangsversion?
- Prüfvorschlag: kontrollierter A/B-Vergleich, dokumentiertes Quellenprotokoll, ein Gegenbeispiel und ein eindeutiger Export-/Lizenzstatus.
- Reifegrad: **indexiert, nicht vollständig fachlich validiert**.

## Nächster Nachweis
Für jeden Begriff eine Primärquelle oder offizielle Tooldokumentation, eine Quellenfundstelle, original erzeugtes Beispiel und manuelles Review ergänzen.
