# Laura Misch: Of Microphones, Stones & Saxophones — STEPS-Quellenkarte V6.4

**Dokument-ID:** `ABLETON-103` · **Stand:** 2026-11-09 · **Fachbereich:** `19_RECORDING_ROOM_MICROPHONES`  
**Originalartikel:** https://www.ableton.com/en/blog/laura-misch-microphones-stones-saxophones/  
**Stichwörter:** Field Recording;Saxophone;Sampling;Acoustic;Ambient  
**Typ:** Interview · **Verifikation:** `article_page_opened` (Original-Webseite oder offizielles Suchergebnis; keine vollständige audiovisuelle Begutachtung)

## Warum diese Quelle in STEPS steht

Mikrofonierung und Field-Recording-Material als kompositorische Klangquelle; Source-to-track-Provenienz beobachten.

## Fachliche Einordnung und Grenzen

- **Direkter Quellenkontext:** Ableton-Artikel oder Künstlergespräch. Es ist keine externe wissenschaftliche Qualitätsbegutachtung.
- **Transferidee / Eigenleistung:** Recording-Labor — Eigene Aufnahme mit dokumentierter Quelle, Abhörvergleich und Verarbeitungsschritten aufnehmen.
- **Gegenprüfung:** Aufnahmeraum und Mikrofonwahl als Kontext, nicht generische Klangregel behandeln.
- **Verknüpfung:** Fachbereich `19_RECORDING_ROOM_MICROPHONES` und übergreifendes Quellenregister in `10_QUELLEN_LIZENZEN`.

## Was Codex damit tun soll

1. Link und Veröffentlichungsdatum erneut prüfen; falls der Artikel auf eine ältere Live-Version verweist, Release-Versionsbezug markieren.
2. Aus dem Original nur eigenständig beschriebene Begriffe, überprüfbare Schritte und eigene Beispiele in die STEPS-KB übernehmen; jede konkrete Behauptung mit Link und Abschnitt versehen.
3. Künstlerzitate/ästhetische Vorlieben als individuelle Aussagen kennzeichnen; niemals universell gültige Musikregeln ableiten.
4. Das oben vorgeschlagene Experiment mit **eigenen Noten, MIDI- und Audioartefakten** ausarbeiten und Hör-/Techniktest protokollieren.
5. Bei Assets Lizenz und Rechte individuell prüfen, bevor Dateien gespeichert, als Trainingsdaten verwendet oder veröffentlicht werden.

## Asset- und Qualitätsstatus

- Asset-Hinweis: `samples` / `asset_link_not_downloaded`.
- Wiedergabe des Originalartikels: **nicht enthalten**.
- Download, Lizenz, konkrete Nutzungsrechte: **nicht freigegeben** ohne separate Prüfung.
- Fachlicher Volltextreview, Video-/Audioanalyse und Tests im STEPS-Repo: **ausstehend**.
