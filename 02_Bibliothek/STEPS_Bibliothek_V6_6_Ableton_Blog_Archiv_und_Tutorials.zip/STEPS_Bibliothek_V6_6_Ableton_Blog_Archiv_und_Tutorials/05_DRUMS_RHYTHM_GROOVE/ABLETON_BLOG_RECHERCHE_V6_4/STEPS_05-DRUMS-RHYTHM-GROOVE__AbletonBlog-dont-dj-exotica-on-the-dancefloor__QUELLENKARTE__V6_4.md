# Don’t DJ: Exotica on the Dancefloor — STEPS-Quellenkarte V6.4

**Dokument-ID:** `ABLETON-144` · **Stand:** 2026-11-09 · **Fachbereich:** `05_DRUMS_RHYTHM_GROOVE`  
**Originalartikel:** https://www.ableton.com/en/blog/dont-dj-moving-in-circles/  
**Stichwörter:** Euclidean;Polyrhythm;Multimeter;Circular Sequencing  
**Typ:** Interview · **Verifikation:** `article_page_opened` (Original-Webseite oder offizielles Suchergebnis; keine vollständige audiovisuelle Begutachtung)

## Warum diese Quelle in STEPS steht

Sequenzieren ungerader Rhythmen und Einsatz von Physical-Modeling-Sounds; kulturelle Bezüge kritisch kontextualisieren.

## Fachliche Einordnung und Grenzen

- **Direkter Quellenkontext:** Ableton-Artikel oder Künstlergespräch. Es ist keine externe wissenschaftliche Qualitätsbegutachtung.
- **Transferidee / Eigenleistung:** Rhythmuslabor — Eigenen Zwei-Takt-Loop mit Step-Grid, Timing-Offset, Velocity und Fills erstellen.
- **Gegenprüfung:** Tempo-Spanne, Groove und Genre-Identität nicht deterministisch gleichsetzen.
- **Verknüpfung:** Fachbereich `05_DRUMS_RHYTHM_GROOVE` und übergreifendes Quellenregister in `10_QUELLEN_LIZENZEN`.

## Was Codex damit tun soll

1. Link und Veröffentlichungsdatum erneut prüfen; falls der Artikel auf eine ältere Live-Version verweist, Release-Versionsbezug markieren.
2. Aus dem Original nur eigenständig beschriebene Begriffe, überprüfbare Schritte und eigene Beispiele in die STEPS-KB übernehmen; jede konkrete Behauptung mit Link und Abschnitt versehen.
3. Künstlerzitate/ästhetische Vorlieben als individuelle Aussagen kennzeichnen; niemals universell gültige Musikregeln ableiten.
4. Das oben vorgeschlagene Experiment mit **eigenen Noten, MIDI- und Audioartefakten** ausarbeiten und Hör-/Techniktest protokollieren.
5. Bei Assets Lizenz und Rechte individuell prüfen, bevor Dateien gespeichert, als Trainingsdaten verwendet oder veröffentlicht werden.

## Asset- und Qualitätsstatus

- Asset-Hinweis: `none` / `no_asset_claim_in_this_study`.
- Wiedergabe des Originalartikels: **nicht enthalten**.
- Download, Lizenz, konkrete Nutzungsrechte: **nicht freigegeben** ohne separate Prüfung.
- Fachlicher Volltextreview, Video-/Audioanalyse und Tests im STEPS-Repo: **ausstehend**.
