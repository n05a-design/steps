# Probability und zufallsbasierte Komposition

**STEPS-Quell-ID:** `ABLETON-089` · **Version:** V6.3 · **Status:** bibliografischer Forschungseintrag, noch kein wissenschaftlich validierter Leitfaden

**Original:** https://www.ableton.com/de/blog/take-chance-producing-probability-live-11/

**Art:** Tutorial · **Hauptordner:** `04_COMPOSING` · **Querbezüge:** `17_DAW_WORKFLOWS`

**Stichwörter:** Aleatorik, Wahrscheinlichkeit, Live 11.

## Warum in der Bibliothek?

Der im offiziellen Ableton-Blog gelistete Beitrag behandelt das Themenfeld **Aleatorik, Wahrscheinlichkeit, Live 11**. Er dient als Ausgangspunkt für stilistische, didaktische und/oder praktische STEPS-Untersuchungen. Seine Präsenz im Register ist kein Beleg dafür, dass ein Video, ein kostenloses Pack oder ein Live-Set bereits vollständig geprüft wurde.

## Verifikationsgrenze

einzelne Artikelseite aufgerufen; nicht vollständig fachlich begutachtet. Kein vollständiger Artikeltext, keine Video- oder Podcast-Transkription und keine von Ableton stammenden Assets in STEPS übernommen. Die Quellen- und Urheberrechtslage muss vor jeder Einbettung gesondert bewertet werden.

## Eigenständige STEPS-Transferaufgabe (neu verfasst)

Erstelle eine originale 16-Takt-Skizze vom Motiv über Variationen bis zu einer klaren Formgrenze. Halte Entscheidungen und Alternativen fest.

## Für Codex

1. Link und Titel bei erneuter Recherche prüfen; Metadaten wie Datum und Autor nur aus tatsächlich belegten Stellen ergänzen.
2. Relevanz zur STEPS-Taxonomie bestätigen und bei Bedarf zusätzliche Fachlabels vergeben.
3. Eine eigene Lehrstudie mit Noten-/MIDI-/Parameterdaten erstellen statt den Originalartikel zu kopieren.
4. Tests und musikalischen Review getrennt dokumentieren; keinen Quellenstatus automatisch erhöhen.
5. Fremde Downloads zunächst nur als URL mit Lizenzstatus `PENDING` verzeichnen.
