# Tony Seltzer und Anysia Kym: Hip-Hop und R&B

**STEPS-Quell-ID:** `ABLETON-060` · **Version:** V6.3 · **Status:** bibliografischer Forschungseintrag, noch kein wissenschaftlich validierter Leitfaden

**Original:** https://www.ableton.com/de/blog/tony-seltzer-anysia-kym-unravelling-the-philostrophy/

**Art:** Downloadinterview · **Hauptordner:** `35_GENRE_STILE` · **Querbezüge:** noch zu verfeinern

**Stichwörter:** Hip-Hop, RnB, Recording, Collaboration.

## Warum in der Bibliothek?

Der im offiziellen Ableton-Blog gelistete Beitrag behandelt das Themenfeld **Hip-Hop, RnB, Recording**. Er dient als Ausgangspunkt für stilistische, didaktische und/oder praktische STEPS-Untersuchungen. Seine Präsenz im Register ist kein Beleg dafür, dass ein Video, ein kostenloses Pack oder ein Live-Set bereits vollständig geprüft wurde.

## Verifikationsgrenze

einzelne Artikelseite aufgerufen; nicht vollständig fachlich begutachtet. Kein vollständiger Artikeltext, keine Video- oder Podcast-Transkription und keine von Ableton stammenden Assets in STEPS übernommen. Die Quellen- und Urheberrechtslage muss vor jeder Einbettung gesondert bewertet werden.

## Eigenständige STEPS-Transferaufgabe (neu verfasst)

Formuliere einen stilistischen Beobachtungsbogen ohne universelle BPM- oder Akkord-Gesetze; teste an mindestens zwei eigenen Miniaturen.

## Für Codex

1. Link und Titel bei erneuter Recherche prüfen; Metadaten wie Datum und Autor nur aus tatsächlich belegten Stellen ergänzen.
2. Relevanz zur STEPS-Taxonomie bestätigen und bei Bedarf zusätzliche Fachlabels vergeben.
3. Eine eigene Lehrstudie mit Noten-/MIDI-/Parameterdaten erstellen statt den Originalartikel zu kopieren.
4. Tests und musikalischen Review getrennt dokumentieren; keinen Quellenstatus automatisch erhöhen.
5. Fremde Downloads zunächst nur als URL mit Lizenzstatus `PENDING` verzeichnen.
