# Dennis DeSantis: Learning Music & Creative Strategies

**STEPS-Quell-ID:** `ABLETON-052` · **Version:** V6.3 · **Status:** bibliografischer Forschungseintrag, noch kein wissenschaftlich validierter Leitfaden

**Original:** https://www.ableton.com/de/blog/dennis-desantis-on-learning-music-and-creative-strategies/

**Art:** Podcast · **Hauptordner:** `09_PRODUKT_DIDAKTIK_SKILL` · **Querbezüge:** `04_COMPOSING`

**Stichwörter:** Didaktik, Kreativität, Stimmungssysteme.

## Warum in der Bibliothek?

Der im offiziellen Ableton-Blog gelistete Beitrag behandelt das Themenfeld **Didaktik, Kreativität, Stimmungssysteme**. Er dient als Ausgangspunkt für stilistische, didaktische und/oder praktische STEPS-Untersuchungen. Seine Präsenz im Register ist kein Beleg dafür, dass ein Video, ein kostenloses Pack oder ein Live-Set bereits vollständig geprüft wurde.

## Verifikationsgrenze

einzelne Artikelseite aufgerufen; nicht vollständig fachlich begutachtet. Kein vollständiger Artikeltext, keine Video- oder Podcast-Transkription und keine von Ableton stammenden Assets in STEPS übernommen. Die Quellen- und Urheberrechtslage muss vor jeder Einbettung gesondert bewertet werden.

## Eigenständige STEPS-Transferaufgabe (neu verfasst)

Erstelle ein eigenes kleines Produktionsbeispiel; dokumentiere musikalische Entscheidung, A/B-Variante und eine verständliche Einschränkung.

## Für Codex

1. Link und Titel bei erneuter Recherche prüfen; Metadaten wie Datum und Autor nur aus tatsächlich belegten Stellen ergänzen.
2. Relevanz zur STEPS-Taxonomie bestätigen und bei Bedarf zusätzliche Fachlabels vergeben.
3. Eine eigene Lehrstudie mit Noten-/MIDI-/Parameterdaten erstellen statt den Originalartikel zu kopieren.
4. Tests und musikalischen Review getrennt dokumentieren; keinen Quellenstatus automatisch erhöhen.
5. Fremde Downloads zunächst nur als URL mit Lizenzstatus `PENDING` verzeichnen.
