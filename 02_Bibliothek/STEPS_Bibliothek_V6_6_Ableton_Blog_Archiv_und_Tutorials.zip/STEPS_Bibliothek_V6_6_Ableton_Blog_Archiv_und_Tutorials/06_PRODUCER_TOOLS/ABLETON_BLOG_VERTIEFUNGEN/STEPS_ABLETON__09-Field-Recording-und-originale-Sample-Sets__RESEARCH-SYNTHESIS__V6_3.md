# Vertiefung 09: Field Recording und originale Sample-Sets

**Belegbarer Ausgangspunkt:** [Ableton-Blog-Beitrag](https://www.ableton.com/de/blog/kmru-spaces/) · **Stand:** 2026-11-09

## Am Artikel belegte Beobachtung

KMRU thematisiert den Zusammenhang von räumlicher Umgebung, Hören und Komposition; ein Field-Recording-Download wird angeboten. Ob eine Weitergabe oder kommerzielle Nutzung erlaubt ist, muss im Einzelfall geprüft werden.

## Wissenschaftliche Grenze

Dieser journalistische Ableton-Beitrag ist eine Praxis- bzw. Produktquelle und ersetzt keine unabhängige musikwissenschaftliche Publikation. Aussagen zu Urheberrecht, historischer Einordnung, psychologischer Wirkung, Plugin-Verfügbarkeit oder Audioqualität bedürfen gesonderter Prüfung. Kein vollständiges Video, Audio, Projekt oder Buch wurde hierfür reproduziert.

## STEPS-Transfer / selbst erarbeitete Übung

Drei eigene Ortsaufnahmen erstellen; Geräuschquelle, Mikrofonposition, Einwilligungen und Nutzung im Track dokumentieren.

**Verknüpfte Fachbereiche:** `19_RECORDING_AKUSTIK`, `04_COMPOSING`, `10_QUELLEN_LIZENZEN`.

**Prüfkriterien:** (a) der Ausgangsartikel ist bibliografisch zuordenbar; (b) die Übung erzeugt ein eigenständiges Artefakt; (c) Beobachtung und Hypothese sind unterscheidbar; (d) technische Testbarkeit und musikalisches Urteil werden getrennt.
