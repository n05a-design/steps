# Vertiefung 06: Probability ist Komposition, nicht Naturgesetz

**Belegbarer Ausgangspunkt:** [Ableton-Blog-Beitrag](https://www.ableton.com/de/blog/take-chance-producing-probability-live-11/) · **Stand:** 2026-11-09

## Am Artikel belegte Beobachtung

Ableton stellt Probability-Funktionen von Live 11 im Zusammenhang mit experimenteller oder aleatorischer Musik vor. Zufall dient als kreativer Parameter, nicht als Garantie einer gelungenen Komposition.

## Wissenschaftliche Grenze

Dieser journalistische Ableton-Beitrag ist eine Praxis- bzw. Produktquelle und ersetzt keine unabhängige musikwissenschaftliche Publikation. Aussagen zu Urheberrecht, historischer Einordnung, psychologischer Wirkung, Plugin-Verfügbarkeit oder Audioqualität bedürfen gesonderter Prüfung. Kein vollständiges Video, Audio, Projekt oder Buch wurde hierfür reproduziert.

## STEPS-Transfer / selbst erarbeitete Übung

Ein seeded 8-Takt-Motiv mit probabilistischen Note-On-Varianten erstellen, beim Test denselben Seed verwenden.

**Verknüpfte Fachbereiche:** `04_COMPOSING`, `08_COMPUTATIONAL_MUSIC`, `11_VALIDIERUNG_QUALITAET`.

**Prüfkriterien:** (a) der Ausgangsartikel ist bibliografisch zuordenbar; (b) die Übung erzeugt ein eigenständiges Artefakt; (c) Beobachtung und Hypothese sind unterscheidbar; (d) technische Testbarkeit und musikalisches Urteil werden getrennt.
