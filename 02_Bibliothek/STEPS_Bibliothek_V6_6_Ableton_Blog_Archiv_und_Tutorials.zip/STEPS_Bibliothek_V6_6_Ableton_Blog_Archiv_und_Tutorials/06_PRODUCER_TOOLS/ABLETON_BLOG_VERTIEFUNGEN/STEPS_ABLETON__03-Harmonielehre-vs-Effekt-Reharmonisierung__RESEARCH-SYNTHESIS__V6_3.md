# Vertiefung 03: Harmonielehre vs. Effekt-Reharmonisierung

**Belegbarer Ausgangspunkt:** [Ableton-Blog-Beitrag](https://www.ableton.com/de/blog/discover-advanced-reharmonizing-techniques-with-live-121s-auto-shift/) · **Stand:** 2026-11-09

## Am Artikel belegte Beobachtung

Der Ableton-Beitrag beschreibt einen Sound-Design-Ansatz zur Reharmonisierung mittels Auto Shift und Resonatoren. Das darf nicht als vollständiges klassisches Harmonie-Analysesystem interpretiert werden.

## Wissenschaftliche Grenze

Dieser journalistische Ableton-Beitrag ist eine Praxis- bzw. Produktquelle und ersetzt keine unabhängige musikwissenschaftliche Publikation. Aussagen zu Urheberrecht, historischer Einordnung, psychologischer Wirkung, Plugin-Verfügbarkeit oder Audioqualität bedürfen gesonderter Prüfung. Kein vollständiges Video, Audio, Projekt oder Buch wurde hierfür reproduziert.

## STEPS-Transfer / selbst erarbeitete Übung

Eine eigene einstimmige Phrase nehmen, harmonische Stützen hinzufügen und zwischen MIDI-Akkordfunktionen und Effektsignal unterscheiden.

**Verknüpfte Fachbereiche:** `02_HARMONIE`, `20_VOCAL_PRODUCTION`, `25_AUDIO_EFFEKTE`.

**Prüfkriterien:** (a) der Ausgangsartikel ist bibliografisch zuordenbar; (b) die Übung erzeugt ein eigenständiges Artefakt; (c) Beobachtung und Hypothese sind unterscheidbar; (d) technische Testbarkeit und musikalisches Urteil werden getrennt.
