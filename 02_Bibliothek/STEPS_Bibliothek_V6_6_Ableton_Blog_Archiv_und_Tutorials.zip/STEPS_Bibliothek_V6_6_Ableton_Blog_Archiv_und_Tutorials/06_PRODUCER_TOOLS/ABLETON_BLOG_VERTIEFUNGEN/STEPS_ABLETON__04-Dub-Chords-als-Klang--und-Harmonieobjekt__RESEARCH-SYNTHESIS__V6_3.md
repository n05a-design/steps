# Vertiefung 04: Dub-Chords als Klang- und Harmonieobjekt

**Belegbarer Ausgangspunkt:** [Ableton-Blog-Beitrag](https://www.ableton.com/de/blog/designing-dub-chords-in-ableton-live-with-el-chooppizza-hotline/) · **Stand:** 2026-11-09

## Am Artikel belegte Beobachtung

Der Beitrag behandelt die Verbindung von Akkordmaterial mit Effekten, Filtern und Modulationen für Dub-Techno-Charakter. Akkordklassen allein erklären nicht die konkrete Klangästhetik.

## Wissenschaftliche Grenze

Dieser journalistische Ableton-Beitrag ist eine Praxis- bzw. Produktquelle und ersetzt keine unabhängige musikwissenschaftliche Publikation. Aussagen zu Urheberrecht, historischer Einordnung, psychologischer Wirkung, Plugin-Verfügbarkeit oder Audioqualität bedürfen gesonderter Prüfung. Kein vollständiges Video, Audio, Projekt oder Buch wurde hierfür reproduziert.

## STEPS-Transfer / selbst erarbeitete Übung

Eine originale Zwei-Akkord-Folge viermal mit unterschiedlichen Filter-/Delay-Einstellungen rendern; harmonische und klangliche Transformation getrennt labeln.

**Verknüpfte Fachbereiche:** `02_HARMONIE`, `03_CHORD_PROGRESSIONS`, `22_SYNTHESE_SAMPLING`.

**Prüfkriterien:** (a) der Ausgangsartikel ist bibliografisch zuordenbar; (b) die Übung erzeugt ein eigenständiges Artefakt; (c) Beobachtung und Hypothese sind unterscheidbar; (d) technische Testbarkeit und musikalisches Urteil werden getrennt.
