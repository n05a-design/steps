# Vertiefung 13: Brendon Moeller: Tempo als Kreativentscheidung

**Belegbarer Ausgangspunkt:** [Ableton-Blog-Beitrag](https://www.ableton.com/de/blog/brendon-moeller-life-begins-at-170/) · **Stand:** 2026-11-09

## Am Artikel belegte Beobachtung

Der Beitrag beschreibt Moellers Wechsel zu 170 BPM als neue kreative Perspektive zwischen Dub-Techno und Drum & Bass; ein Samplepack wird angeboten. Nicht als universelle Genretempo-Regel ableiten.

## Wissenschaftliche Grenze

Dieser journalistische Ableton-Beitrag ist eine Praxis- bzw. Produktquelle und ersetzt keine unabhängige musikwissenschaftliche Publikation. Aussagen zu Urheberrecht, historischer Einordnung, psychologischer Wirkung, Plugin-Verfügbarkeit oder Audioqualität bedürfen gesonderter Prüfung. Kein vollständiges Video, Audio, Projekt oder Buch wurde hierfür reproduziert.

## STEPS-Transfer / selbst erarbeitete Übung

Originalbeat bei 85/170 BPM mit identischer musikalischer Zeit und anderer Beat-Akzentuierung vergleichen.

**Verknüpfte Fachbereiche:** `05_DRUMS_RHYTHM_GROOVE`, `35_GENRE_STILE`, `04_COMPOSING`.

**Prüfkriterien:** (a) der Ausgangsartikel ist bibliografisch zuordenbar; (b) die Übung erzeugt ein eigenständiges Artefakt; (c) Beobachtung und Hypothese sind unterscheidbar; (d) technische Testbarkeit und musikalisches Urteil werden getrennt.
