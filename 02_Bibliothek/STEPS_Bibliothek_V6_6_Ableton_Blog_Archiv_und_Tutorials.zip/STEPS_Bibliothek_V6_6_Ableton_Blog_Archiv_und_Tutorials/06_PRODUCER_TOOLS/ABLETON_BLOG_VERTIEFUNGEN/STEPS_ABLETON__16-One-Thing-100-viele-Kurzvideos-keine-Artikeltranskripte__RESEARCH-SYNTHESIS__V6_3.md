# Vertiefung 16: One Thing 100: viele Kurzvideos, keine Artikeltranskripte

**Belegbarer Ausgangspunkt:** [Ableton-Blog-Beitrag](https://www.ableton.com/de/blog/one-thing-leads-to-another-100-music-making-inspirations/) · **Stand:** 2026-11-09

## Am Artikel belegte Beobachtung

Ableton fasst eine Serie mit 100 kurzen Inspirationen zusammen; aus dem Sammelartikel allein sind nicht alle Einzelvideos fachlich geprüft. Separate Video-IDs/Transkriptlizenz offen.

## Wissenschaftliche Grenze

Dieser journalistische Ableton-Beitrag ist eine Praxis- bzw. Produktquelle und ersetzt keine unabhängige musikwissenschaftliche Publikation. Aussagen zu Urheberrecht, historischer Einordnung, psychologischer Wirkung, Plugin-Verfügbarkeit oder Audioqualität bedürfen gesonderter Prüfung. Kein vollständiges Video, Audio, Projekt oder Buch wurde hierfür reproduziert.

## STEPS-Transfer / selbst erarbeitete Übung

Fünf originale 5-Minuten-Experimente mit Reflexionsfragen entwerfen, ohne die Kurzvideos zu kopieren.

**Verknüpfte Fachbereiche:** `16_CREATIVE_DIRECTION`, `04_COMPOSING`, `09_PRODUKT_DIDAKTIK_SKILL`.

**Prüfkriterien:** (a) der Ausgangsartikel ist bibliografisch zuordenbar; (b) die Übung erzeugt ein eigenständiges Artefakt; (c) Beobachtung und Hypothese sind unterscheidbar; (d) technische Testbarkeit und musikalisches Urteil werden getrennt.
