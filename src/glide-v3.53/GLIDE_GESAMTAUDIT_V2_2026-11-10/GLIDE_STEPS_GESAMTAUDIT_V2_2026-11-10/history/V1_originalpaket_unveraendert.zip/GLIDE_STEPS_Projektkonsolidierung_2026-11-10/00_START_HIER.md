# START HIER — Entscheidungsvorbereitung

## Sofortige Priorität

**Glide 3.53.0 nicht gleich „voll grün“ setzen.** Im Quellstand `9e767bea5e21063466a28ac3a679406484ad5d5f` ist 3.53.0 auf `main`; die zuletzt eingesehenen GitHub-Actions liefen zum Teil noch. Der kanonische QA-Bericht erklärt den letzten dokumentierten Windows-Lauf mit 130/131 Schritten (Bild-Sichtprüfung ausgenommen), `release_ready=false`; native Linux-/macOS-Gesamtmatrix und Teile der Bedien-/DPI-Abnahme waren offen. Ein einzelner erfolgreicher macOS-Paketlauf ersetzt die Vollmatrix nicht.

**Die zwei Bereiche bedeuten hier zwei Arbeitsflächen innerhalb einer App**, nicht zwingend zwei unabhängige OS-Fenster. Diese konservative Auslegung ist ein *Vorschlag*: Hauptbereich plus sekundärer Detail-/Werkzeugbereich, jeweils mit Lebenszyklus und schaltbarer Sichtbarkeit. Kein separater `Toplevel` ohne gesonderte Entscheidung.

## Empfohlene Reihenfolge

1. Laufenden Glide-Copilot-Arbeitsstand abschließen und auf eigenen Quellcommit/PR, Version, Datenformat und CI dokumentieren. Keine parallel schreibenden Agenten im gleichen Glide-Checkout.
2. 3.53.0-Prüfmatrix einschließlich Plattformen, Paket-/Startlauf, visueller/menschlicher Abnahme und Datenintegrität gegen **denselben** SHA schließen; `release_ready` erst dann gemäß Originalvertrag entscheiden.
3. Glide-System V1.15 als technischen *Katalog* einfrieren; jedes der 25 Bausteinpakete auf konkrete Importkette, Ressourcen, Lizenz und Zustandsbesitz prüfen. Nicht das gesamte `app.pyw` als Library kopieren.
4. Steps-Rechte- und Dokumentationsaudit abtrennen; bestehende Steps-Artefakte nicht neu erzeugen, wenn sie bereits bestehen. Eigenes Repo und eigene Produkt-/Datenidentität bewahren.
5. Neutralen Shell-Vertrag definieren; in isoliertem Branch einen minimalen Referenzklienten mit **zwei Inhaltsflächen** und funktionslosen/neutralen Navigationseinträgen bauen, ohne Glide zu amputieren.
6. Erst nach Shell-Abnahme die musikalischen Domain-Modelle, persistente Progressionen, Lehr-UX, Skill und spätere MIDI-/Audio-Adapter integrieren.
7. Die Shared-Module erst nach Isolationstests in mindestens Glide und Steps versionieren/publizieren. Keine automatische Quellcode-Synchronisation.

## Was bis zum Reset der KI-Kontingente sinnvoll parallel vorbereitet wird

- **Copilot VS Code:** nur den bereits laufenden Glide-Stand abschließen, regressionssicher und ohne Steps-Code dazwischen.
- **ChatGPT (dieses Paket):** Source-of-Truth, Entscheidungen, Pfad- und Modul-Mapping, Prüfgates, Agentprompts.
- **Claude/Fable nach eigener Verfügbarkeit:** Architektur-, Adapter- und UI-Refactoring in einem eigenen Steps-Branch **nach** Basisfreeze. Die als „Fable 5.2“ bezeichnete Verfügbarkeit und getrennte Guthaben sind Nutzerangaben; hier nicht unabhängig verifiziert.
- **Gemini/Antigravity:** fachliche/architektonische Gegenprüfung in anderer Arbeitskopie, keine konkurrierenden Änderungen in Glide.
- **zweiter ChatGPT-Account:** unabhängiges adversariales Review der Lizenzen, Prüfberichte, Abnahmekriterien; nicht als zweite autoritative Projektquelle.

## Freigaben, die erforderlich bleiben

Basiskommit, konkretes 2-Flächen-Verhalten, Steps-MVP, neu zu verwendende Logos/Identitäten, Lizenzstatus fremder Materialien und Veröffentlichungsumfang. Agenten dürfen diese Lücken nicht durch Vermutung schließen.
