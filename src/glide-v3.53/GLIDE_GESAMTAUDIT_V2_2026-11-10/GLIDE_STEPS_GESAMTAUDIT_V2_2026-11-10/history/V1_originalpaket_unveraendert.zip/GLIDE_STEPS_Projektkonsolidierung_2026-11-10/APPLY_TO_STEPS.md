# Veröffentlichung und sicherer Import in Steps (manuell zu prüfen)

**Status:** Das GitHub-Repositoy ist öffentlich. Diese ZIP-Datei enthält auch die internen Angaben zur persönlichen Agenten-/Kontingentplanung und die ursprüngliche Arbeitsmappe. Daher **nicht das gesamte Paket öffentlich hochladen**. Bei der versuchten Erstellung eines separaten GitHub-Dokumentationsbranches meldete die Verbindung `403 Resource not accessible by integration`, obwohl Metadaten Schreibrechte anzeigen. Es wurde deshalb **kein** Remote-Commit oder PR erstellt.

## Sicherer publizierbarer Teil

Nach Review können die **technischen Dokumentationsdateien** mit neuen Namen in einem separaten Steps-Branch übernommen werden. Beispielmapping (nur Vorschlag):

| In dieser ZIP | Im Steps-Repository |
|---|---|
| `README.md` | `docs/project/overview/Glide_Steps_Konsolidierung_INDEX.md` (nicht Root-README überschreiben) |
| `00_START_HIER.md` | `docs/handover/Glide_Steps_START_HIER.md` |
| `docs/project/PROJECT_OVERVIEW.md` | `docs/project/overview/Glide_Steps_PROJECT_OVERVIEW.md` |
| `docs/project/SOURCE_INDEX_AND_PROVENANCE.md` | `docs/project/provenance/Glide_Steps_SOURCE_INDEX.md` |
| `docs/project/CONTRADICTIONS_GAPS_DEDUP.md` | `docs/project/overview/Glide_Steps_CONFLICTS_AND_GAPS.md` |
| `docs/project/DECISION_REGISTER.md` | `decisions/GLIDE_STEPS_PROPOSALS.md` (nur Entwurf, keine accepted ADRs) |
| `docs/architecture/*.md` | `docs/architecture/` (neue Dateinamen, vorhandene Dokumente erhalten) |
| `docs/roadmap/*.md` | `docs/roadmap/` (neue Dateinamen, Vorlage-/Gatedocs) |
| `docs/qa/*.md` | `docs/roadmap/QA_GATES.md` (Steps-Scaffold hat derzeit kein `docs/qa`) |
| `docs/knowledge/*.md` | `knowledge/README_GUIDE_FOR_INGEST.md` |
| `prompts/*.md` | `docs/roadmap/agent_prompts/` (nicht bestehende alte Prompts überschreiben) |

## Privat lassen / bereits kanonisch vorhanden

- **`docs/project/PROJECT_CONTEXT_FROM_CHAT.md`** und **`docs/roadmap/AI_TOOLS_RESOURCE_PLAN.md`** enthalten den privaten Account-/Nutzungskontext. Für öffentliches GitHub vor Veröffentlichung redigieren oder nur lokal behalten.
- **`inventories/`**: historische XLSX/CSV nur nach Source-/Privacy-/Rights-Review hochladen; nicht als aktuelle Modulautorität.
- **`research_references/`**: sind bereits unter `research/notes/deep-research/legacy/` im Steps-Repository vorhanden. **Keine identischen zweiten Versionen** erzeugen.
- **Root-README/AGENTS/SKILL/Styles** des Steps-Repos nicht ohne eigenen Arbeitsauftrag ersetzen.

## Sicheres Git-Verfahren

1. `main` SHA und sauberen lokalen `git status` lesen; keine offenen Arbeiten überschreiben.
2. Eigenen Branch von der bestätigten Steps-Baseline anlegen. Nur die ausdrücklich freigegebenen publizierbaren Markdown-Dateien in die Zielorte kopieren, keine Quell-/Bucharchive.
3. `git diff --check`, Markdownlink-/Pfadeprüfung, Datenschutz-/Rechteprüfung, Dokument-Source-of-Truth gegen bestehende `AGENTS.md` und Schritte-Overview prüfen.
4. `git add` **nur die ausgewählten Texte**, `git diff --cached` und `git status` kontrollieren. Commit/Push erst nach expliziter menschlicher Prüfung/Autorisierung; Draft-PR ohne Merge.
5. PR mit SHA, Quellen, Widersprüchen, offenen Rechtsfragen und nicht ausgeführten Tests versehen; Glide `main` und Steps `main` unverändert bis Review.

**Kein automat. Korrigieren der alten 992-Zeilen-Steps-Overview:** deren historische Quellenabdeckung bleibt eigenständig; ein neuer Publikationsindex verlinkt sie und grenzt alte Live-Claims ab.
