# Arbeitsauftrag 07_STEPS_SKILL_AND_EVALUATION — Fach-Skill als dünner belegter Workflow

**Auftragsart:** Nur nach expliziter Freigabe implementieren; vorher Analyse.

### Rolle und Ausgangsquellen

Du arbeitest als Senior Python-/Tk-Architekt, UX-/QA-Engineer und überprüfbarer KI-Entwicklungsagent für **Glide (Python/Tkinter)** und **Steps (eigene Musik-Domain)**. Lies vor Beginn `00_START_HIER.md`, `docs/project/PROJECT_OVERVIEW.md`, `docs/project/CONTRADICTIONS_GAPS_DEDUP.md`, `docs/architecture/SHARED_CORE_CONTRACT.md`, `docs/qa/ACCEPTANCE_MATRIX.md` sowie die gültigen GitHub-`AGENTS.md`/Glide-System-Dokumente. Nutze **den echten aktuellen Code** und den tatsächlich ausgecheckten Commit statt alter Chat-Zusammenfassungen. Bestätige SHA, Repo, Branch, Git-Status, Lizenz, Python/Tk-Version und relevante Source-of-Truth.

### Grenzen für jede Aufgabe

- Jede Aussage als `CONFIRMED / EXISTING / PROPOSED / UNVERIFIED / TESTED` oder bei Konflikt `CONFLICTING` kennzeichnen. Implementierung erst bei freigegebener Aufgabe und geschlossenem Vorgate.
- Keine Änderung an `main`, keine automatischen Merge/Push/Tag/Release, keine Geschichte umschreiben, keine Löschung von Originalen oder Tests; sichere nur isolierte Arbeitskopien.
- Glide-Produktverhalten, seine Testfälle und Userdaten erhalten; keine echten Userdaten in Tests/Artefakten, getrennte RuntimePaths/temporäre Testdaten. Offline-first; keine heimliche Cloud-/Account-/Netzwerk-Abhängigkeit.
- Neue Tk-UI nur im Tk-Hauptthread; `after`-Callbacks beim Teardown bereinigen, Eventloop nicht blockieren; Plattform/DPI/Focus/Font/Contrast prüfen; keine unbemerkte Verdopplung von Datenspeicher- oder Command-Mutationspfaden.
- Vorhandene Bausteine bevorzugen; Fachlogik Tk-frei; Rechte/Provenienz jeder fremden Ressource prüfen; historische Fehler oder Lizenz-Unsicherheiten nicht verdecken.

### Abschlussformat (verbindlich)

`Basis`, `Ziel-/Branch`, `geprüfte Quellen`, `tatsächliche Änderungen (Datei/Zeile/Diff)`, `Architektur-/Datenfolgen`, `Tests bestanden / fehlgeschlagen / nicht ausgeführt` mit Befehlen/Runtime, `offene Risiken`, `Abnahmegrad`, `nächster kleinster Schritt`. Nenne niemals nur „alles grün“, wenn eine Achse ungeprüft ist.


### Konkret zu erledigen

Überarbeite Root SKILL (Router) und `skills/music-harmony-coach` so, dass Wissen aus `knowledge/` referenziert und zitiert wird. Definiere Trigger, Index-Navigation, Quellenbeleg, Konfidenz, Umgang mit Widersprüchen/fehlenden Buchseiten, DE/EN-H-B, alternative Harmoniefunktionen und MIDI-Metadaten.

### Geplante Artefakte / Übergabe

SKILL.md + Referenz/Index mit Quellen-IDs, Testsets für Analyse/Komposition/Didaktik sowie hallucination/retrieval/rechtefälle, Versionshinweise.

### Risiken und harte No-Touch-Grenzen

Keine Duplikation sämtlicher Lehrtexte im Skill, keine erfundenen Literaturbelege, keine automatischen Git-Änderungen an großen Research-Archiven.

### Messbare Abnahmekriterien

Positive/negative Evals dokumentiert, Retrievalpfad nachweisbar, unbekannte Quellen führen zu offener Kennzeichnung.

### Vorgehensvorschlag

1. Relevanten Basisstand und Pflichtquellen vollständig abgleichen; offenen Widerspruch oder beschädigte Fixture als Blocker melden, nicht wegkorrigieren.
2. Bei Implementierung zuerst minimalen reproduzierbaren Ausgangstest und negative Gegenprobe schreiben; Code nur innerhalb der genehmigten Pfade in einem separaten Branch ändern.
3. Je Änderung Verhalten/Seitenwirkungen an Nachbaransichten, Daten-/Undo-/Savegrenzen, importierten Ressourcen, Plattformen und Benutzerzuständen prüfen.
4. Doku am vorgesehenen kanonischen Ort pflegen; Tests auf identischen Quellbytes ausführen. Keine Aussage über unzugängliche Laufzeit, Rechtslage oder reale Nutzung ohne Nachweis.
5. Auditierbare Übergabe nach obigem Format abgeben, Git-Änderungen bis zur Human-Review offenlassen.
