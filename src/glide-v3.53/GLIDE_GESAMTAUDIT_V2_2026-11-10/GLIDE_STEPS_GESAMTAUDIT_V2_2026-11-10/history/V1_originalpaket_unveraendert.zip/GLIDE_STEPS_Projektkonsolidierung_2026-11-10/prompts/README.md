# Agent-Prompts — Reihenfolge und Umgang mit Autorisierung

Alle Dateien sind **Auftragsvorlagen**, keine Aufforderung, sie sofort auszuführen. Benenne vor jeder Ausführung `Basis-SHA`, `Agent`, `Arbeitskopie/Branch`, `Freigabe`, `Dateien im Scope` und `Ziel-Gate`. Ohne ausdrücklich dokumentierte Freigabe **keine** Merges, Pushes, Releases, Tags, History-Rewrites oder destruktive Daten-/Quellbereinigung. Das Erstellen eines Draft-PR für Dokumente ist keine Produktionsfreigabe.

**Vor jeder Implementierung** `00_EVIDENCE_AND_PRECHECK.md`, `docs/project/DECISION_REGISTER.md`, `docs/qa/ACCEPTANCE_MATRIX.md` und den maßgeblichen GitHub-Quellstand lesen. Keine frei geratenen APIs, Dateipfade, Testresultate oder bereits abgeschlossenen Module. Tests in isolierten Verzeichnissen und nur mit synthetischen Daten. UTF-8, Python/Tk, Windows/macOS/Linux, Offline/Privacy und Lizenzbedingungen.

Die Prompts sind entlang der Gates getrennt: 01 Freigabe, 02 Inventur, 03 Shell, 04 Shared Core, 05 Musikdomäne, 06 Wissen, 07 Skill, 08 UI, 09 MIDI/Drums, 10 Daten/Undo, 11 QA, 12 Performance/A11y, 13 Design, 14 Review/Handover, 15 Repo/Docs-Provenienz, 16 Projekt-Featureplanung. Jeder Prompt kann isoliert vergeben werden und verlangt einen strukturierten Abschlussbericht.
