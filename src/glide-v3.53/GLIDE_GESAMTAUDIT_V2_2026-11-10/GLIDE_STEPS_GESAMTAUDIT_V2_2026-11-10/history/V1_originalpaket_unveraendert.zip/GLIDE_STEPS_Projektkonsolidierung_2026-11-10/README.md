# Glide → Steps — Projektkonsolidierung und Arbeitsaufträge

**Dokumentationspaket: 10. November 2026 | Status: REVIEW-ENTWURF, keine Produktfreigabe.**

Dieses Paket ist eine *nichtdestruktive* Bestands- und Arbeitsplanung für die kontrollierte Ableitung eines wiederverwendbaren Glide-Desktop-Grundgerüsts und seine Verwendung in der unabhängigen Musik-App Steps. Es ändert weder Glide-Code noch Datenbanken und kopiert keine fremden Bücher, MIDI-Dateien oder Wettbewerbsassets.

## Verifizierte GitHub-Anker

- Glide: `n05a-design/glide-to-do`, `main` **`9e767bea5e21063466a28ac3a679406484ad5d5f`**, `VERSION=3.53.0`, `GLIDE_SYSTEM_VERSION=1.15`.
- Steps: `n05a-design/steps`, `main` **`75329fef46878a5ac816cef3690e612a9e8fe52c`**, `VERSION=0.0.0-dev`, vorhandene Architektur- und Archivstruktur, noch keine ausführbare Musik-App.
- Glide-Katalog: [Systemregister V1.15](https://github.com/n05a-design/glide-to-do/blob/9e767bea5e21063466a28ac3a679406484ad5d5f/01_Repository/Glide/src/glide/README.md), *maßgeblich*, nicht historische Excel-Liste.
- Glide-Gates: [QA-Bericht](https://github.com/n05a-design/glide-to-do/blob/9e767bea5e21063466a28ac3a679406484ad5d5f/01_Repository/Glide/docs/07_QA_BERICHT.md).
- Steps-Vorarbeiten: [konsolidierte Steps-Overview](https://github.com/n05a-design/steps/blob/75329fef46878a5ac816cef3690e612a9e8fe52c/docs/project/overview/Steps_Projekt_Overview_konsolidiert_2026-11-09.md), [Architektur](https://github.com/n05a-design/steps/blob/75329fef46878a5ac816cef3690e612a9e8fe52c/docs/architecture/architecture.md), [Gaps](https://github.com/n05a-design/steps/blob/75329fef46878a5ac816cef3690e612a9e8fe52c/research/gaps/OPEN_GAPS.md).

## Einstieg und kanonische Quellen

1. `00_START_HIER.md` – Reihenfolge und Sofortmaßnahmen.
2. `docs/project/PROJECT_CONTEXT_FROM_CHAT.md` – Nutzerauftrag mit aktuellem Arbeitskontext; keine stillen Zusatzentscheidungen.
3. `docs/project/PROJECT_OVERVIEW.md` – ein integriertes, dedupliziertes Zielbild.
4. `docs/project/SOURCE_INDEX_AND_PROVENANCE.md` – Quelle, Umfang, Evidenzgrenze.
5. `docs/project/CONTRADICTIONS_GAPS_DEDUP.md` – Widersprüche, Lücken, Behandlung von Duplikaten.
6. `docs/architecture/` – Wiederverwendung, UI-Shell, Ports/Adapter und Modulzuordnung.
7. `docs/roadmap/` – Qualitäts-Gates, Arbeitsplanung, Ressourcen.
8. `docs/knowledge/` – Forschung/Skill/Quellenrechte.
9. `docs/qa/` – Test- und Freigabevertrag.
10. `prompts/README.md` – präzise agentenfähige Einzelaufträge.
11. `inventories/` – historische XLSX-Daten getrennt, dokumentiert, ohne Quellstand-Aufwertung.

**Vollständigkeit:** Das Repository-Verzeichnis beider HEADs und die benannten Kern-/Governance-Unterlagen wurden abgeglichen. Das ist **keine** Behauptung, alle 3.473 Git-Dateien, alle historischen PDFs, alle Bücher, ZIP-Inhalte, früheren Chats und den noch aktiven lokalen Copilot-Stand Zeile für Zeile gelesen zu haben. Diese Lücken werden ausdrücklich protokolliert. Alle geprüften Originaldokumente und historischen Nachweise bleiben in ihren kanonischen Ursprungsorten verlinkt; nichts wird durch die Übersicht ersetzt.

**Keine Umsetzung:** Weder Glide 3.53 noch eine neue Shell, eine Shared-Library, eine musikalische Engine, eine Skills-Ingestion oder ein Build wurden durch dieses Dokumentenpaket implementiert. Tests siehe `docs/qa/ACCEPTANCE_MATRIX.md`.
