# KI-Werkzeuge — verteilte Arbeit, Kontingente und Übergabeprotokoll

Stand aus Nutzerangabe 10.11.2026: reguläre ChatGPT-Tokens voraussichtlich ab **Mittwoch, 11.11.2026**, Claude regulär ab **Donnerstag, 12.11.2026**. Getrennte Claude-„Fable 5.2“-Guthaben wurden berichtet, sind hier nicht verifiziert; das lokale Guthaben-/Preismodell bleibt unerheblich für technische Entscheidungen.

| Werkzeug | Fokus | Darf schreiben? | Übergabepflicht |
|---|---|---|---|
| GitHub Copilot / VS Code | aktive Glide-3.53-Arbeit, Regressionen und finaler Checkout | **nur** eigene autorisierte Glide-Arbeitskopie/Branch | commit SHA, Tests, pending PR, diff, offene native Abnahme |
| ChatGPT #1 | Dokumentenabgleich, Architektur, Repo-Kontrakte, Draft-PR-Dokumentation | nur Dokumentationsbranch | source map, Annahmen, offene IDs, Verlinkung |
| Claude / Fable | tiefes Dependency-Graph-Audit und kleine Schritte zur Steps-Shell | **separater Steps-Featurebranch**, nach G0/G1 | Modulports, Änderungen, rote Gegenproben, Storybook-artige UI-Stati |
| Gemini / Antigravity | unabhängiger Architektur- und Musiktheorie-Gegencheck, Kontraktkritik | bevorzugt read-only; eigener Reviewbranch | Einwand mit Datei/Zeile/fehlgeschlagenem Test, Priorität |
| ChatGPT #2 | adversariales QA-/Rechte-/Dokumentenkonsistenzreview | read-only bis ausgewählter PR | P0/Bug/Unsicherheit, Abnahmematrix, keine stillen Features |

## Tokenbudget ohne Abstriche bei Evidenz

Dicke historische Dokumente **einmal** kanonisch indexieren statt fünf Modellen vollständige Dumps senden. Jeder Auftrag erhält nur `REPO`, Base SHA, Modulpfade, maßgebliche Docs, Acceptance Gates und früheren Handover. Kleine überprüfbare PRs bevorzugen. Keine Agenten dazu anhalten, Tests abzuschwächen, offensichtliche Rotfälle wegzudokumentieren oder ein künstliches fertiges Framework zu behaupten.

## Agent-Handover-Header (immer kopieren)

```text
Projekt: Steps | getrennt von Glide
Basis Glide: <SHA> / Glide-System: <Version> / QA-Gate: <Beleg oder offen>
Basis Steps: <SHA> | Branch/Arbeitskopie: <branch> | Git status: <status>
Zuständiger Prompt: prompts/<Datei> | Freigegebener Scope: <betroffene Pfade>
Kanonische Quellen: <Links/Dateien> | Fach-ADR: <ID/Status>
Vorher-Zustand: <Beleg> | Änderung: <Diff> | Danach: <Testlauf-ID/Runtime>
Nicht geprüft: <Liste> | Risiken: <Liste> | Nächste Aktion: <eine>
```

## Branch-Kollisionen vermeiden

Vor Start `git fetch`/read-only Base-Prüfung; eigene Worktrees oder getrennte Repos unter kurzen lokalen Pfaden (OneDrive/Windows-Pfadlängen beachten). Keine gleichzeitigen Schreibaktionen auf `app.pyw`, `README.md`, `GLIDE_SYSTEM_VERSION` oder die Steps-Registry. Geteilte Entscheidungen über zentrale ADRs und den Hauptintegrator, nicht parallele private Chat-Annahmen.
