# Glide 3.53 → neutrale Shell mit zwei Arbeitsflächen

**Anforderung vs. Vorschlag:** Der äußere Glide-Rahmen einschließlich Navigation, Kopf, Settings, Branding, Themes, Text-/Symbolbuttons und Seitenlisten-Zuständen soll sichtbar bleiben. Als **Vorschlag** realisieren wir *eine* Tk Root mit zwei unabhängig bestückbaren **Inhaltsflächen**, nicht zwei OS-Fenster. Layoutalternativen müssen fachlich entschieden werden.

## Visueller Zielzustand

```text
┌─────────────────────────────────────────────────────────────────────────┐
│ Logo  Steps / Ansichtstitel + Unterzeile       Suche  [Icons] [Settings]│
├─────────────────┬─────────────────────────────┬───────────────────────┤
│ Sidebar         │ PRIMARY WORKSPACE           │ SECONDARY WORKSPACE   │
│ [⇤ collapse]    │                             │ [hide / reopen]       │
│ Navigation:     │ Chord/Progression/Drum/      │ Details, Theorie,     │
│ • Explorer      │ Learning content            │ Quellen, Einstellungen│
│ • Progressions  │                             │                       │
│ • Drum Patterns │                             │                       │
│ • Theory        │                             │                       │
│ • Library       │                             │                       │
├─────────────────┴─────────────────────────────┴───────────────────────┤
│ Prozess-/Fehler-/Statusrolle (falls benötigt, kein leeres Dauerpanel)  │
└─────────────────────────────────────────────────────────────────────────┘
```

## Preservation-Matrix

| Element | Muss erhalten | Muss neutralisiert/ersetzt werden | Erforderlicher Nachweis |
|---|---|---|---|
| Fensterkopf | Logo-Ort, View-Titel, Unterzeile, Theme-/Icon-Tokens, Action-Layout | Glide-Logo/Text und Task-spezifische Kennzahlen | Pixel-/Geometrie und Semantik in hell/dunkel/4 Fonts |
| Seitenleiste | show/hide, collapse/expand, Scroll/Fokus, Breite, Navigation, aktiver Eintrag, Keyboard | Glide-LIST_KINDS und Fachaktions-Handler | Zustandstabelle, persistierte Auswahl, Resize, Back/Forward |
| Seitenliste | visuelle Einträge/Icons und Fokus | Seiten-/Listen-/Notizen-/Zeichnungen-CRUD | `NavigationItem` mit pure ID und gebundener Action oder disabled reason |
| 2 Inhalte | Canvas/Scroll/resize, empty states, re-entrant mount/unmount | TaskEditor/Pinnwand/Home-View und direkte `ListApp`-Felder | no data writes, teardown callbacks, focus/restore |
| Suche | Feld/clear/focus/shortcut, Theme | Tasksuche/Index/Task-Results | neutraler SearchProvider; leere Results, Disabled-State |
| Settings | UI, Theme, Schrift, Gewicht, Skalierung, Fensterlage | Glide-Daten-/Aufgaben-/Exportsettings | isolierter Steps-SettingsStore, Alias-/Migrationstests |
| Plattform | Kompaktmodus-Policy, native OS-Menüs, Icons, DnD optional | Glide-App-ID, notification texts, filetype bindings | nativ pro OS, Shortcut/Accessibility |
| Prozesskommunikation | Fehler/status/Loading/Progress, lokale Diagnostik | task-spezifische Quellen/Fehlermeldungen | error & cancellation; keine UI-Blockade |
| Dateien | atomar, Lock/Recovery/Backup-Vertrag | `GLIDE_DATA_DIR`, Dateien aus Task-Schema | `STEPS_DATA_DIR`/explizite RuntimePaths, no cross app mutation |

## Entkopplungsroute ohne Big Bang

**R0 Quell- und Verhaltensinventur**: Vorher-Screenshots/Widgetbaum/Action-IDs, App-Start, State-Owner, Importgraph, Userdata-Pfade, Tests, gewählte Größen (860×700 normal, kompakt 480×560 aus `compact_mode` – zunächst *nur Quelle*, nicht automatisch neue Steps-Mindestmaße). Tests für echten 3.53-Stand erfassen.

**R1 Contract-first**: `AppIdentity`, `RuntimePaths`, `ThemeProvider`, `CommandRegistry`, `NavigationProvider`, `WorkspaceHost` definieren. Core-Vertrag ohne `from glide...` und ohne Tk für Rechenlogik.

**R2 Strangler-Schnitt**: bestehende Glue-Methoden in `ListApp` über Adapter auf Core-Ports umleiten, jeweils ein kleiner PR. Glide-Fachverhalten bleibt währenddessen identisch und getestet. Kein pauschales Deaktivieren von Tasten, die auf Daten zugreifen, ohne klare Disabled-Semantik.

**R3 Steps-Referenzhost**: eine separate Steps-Startdatei und root/2 Slots mit neutralen Dummy-Views. B01/02/03/04/09/19/24 selektiv nutzen, bei jedem Modul vollständige Import-/Ressourcen-/Lizenzkette explizit prüfen.

**R4 Ersetzen der Businessflächen**: Task/Note/Pinboard-Datenmodelle bleiben in Glide; in Steps neue Musik-ViewModels und Commands anbinden. Beide Slots sind bei fehlenden Features leer/erklärt, nicht inaktive Taskflächen.

**R5 Freeze + QA**: zwei parallele Produkte mit selben Core-API-Commit und eigener stabiler Branding-/Settings-/Backup-/Data-ID. Windows/Linux/macOS mit verschiedenen Tk-Versionen, Scale/Screen, Alt/Cmd, Menüs, Fokus, Fensterzustand und Tastaturbedienung.

## Zwingende Regressionen

- Sidebar vier Varianten: volle Breite, eingeklappt, verborgen, wieder eingeblendet; Tastatur und Maus; aktive Navigation bleibt stabil.
- Secondary-View: öffnen, schließen, ersetzen, Schnellfolge, `after`-Cleanup, Fokus zurück und keine reservierte leere Restfläche; kleine Fenster und großes Textmaß.
- Wechsel aller 4 aktuellen Fonts, normal/fett, Designpaare, farbige Rollen/kontrast, UI-Icon-Fallback (DejaVu Sans weiterhin in Glide), gespeichert über Neustart.
- Tk Root schließen während Worker/Callback/Settings-Speichern; keine Tote-Widget-Ausnahme, keine verschluckten Fehler.
- Bei Shell-Import und Start werden keine echten Glide-Daten geöffnet, gelockt oder geändert. Test- und Produktverzeichnis werden vor Import injiziert.
- Zwei Slots rendern unabhängig von Fachdaten; Steps gehört allein der Musik-Datenmutationspfad.

## Stop-Kriterien

Verpflichtende Glide-Tests rot, veränderte Produktdaten, undokumentierter Fremdcode, unklarer Thread-/Focus-Lifecycle oder nicht reproduzierbare UI-Änderung → Arbeit stoppen, Ursache mit Gegenprobe zeigen und Rückbau im Branch vorbereiten. Kein „UI sieht gut aus“ als einzige Abnahme.
