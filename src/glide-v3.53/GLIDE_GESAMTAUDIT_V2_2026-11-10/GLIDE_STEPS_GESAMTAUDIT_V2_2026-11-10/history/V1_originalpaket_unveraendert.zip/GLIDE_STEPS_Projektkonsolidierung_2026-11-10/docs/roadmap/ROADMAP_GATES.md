# Roadmap: Abhängigkeiten, überprüfbare Gates und Definition of Done

**Keine erfundenen Termine.** Der reale 3.53-Abschluss und KI-Kontingente sind nicht unabhängig durch den Plan steuerbar.

| Gate | Ziel | Konkreter Ausgang | Abnahme-Kriterium / Stop |
|---|---|---|---|
| G0 | Glide 3.53 eingefroren | Main-SHA, CI, Modulregister, Windows-QA-Bericht | Windows/Linux/macOS am gleichen SHA + native Pakete/Starts, Datenintegrität und Sicht-/Bedienmatrix belegt; keine kritischen roten Tests |
| G1 | Bestands-/Rechtebasis | Steps/Git-Tree, Bibliothek, historisches Excel | Provenienz, Rechte, Produkt-/App-ID, Deduplikationsplan, Quellenhashes und Blocker geklärt |
| G2 | Core-Ports und Architektur ADR | System B01–B25 | Ports für Theme/Navigation/2 Slots/Identity/Settings/Lifecycle bestätigt, keine Glide-Domain-Imports |
| G3 | Neutrale Zwei-Flächen-Shell | isolierter Branch | äußerer Chrome und Sidebarzustände, zwei austauschbare Slots, startbar mit Dummy-Inhalten, no cross-data |
| G4 | Steps-Domain Foundation | `src/steps` Platzhalter | pure Modelle Pitch/Chord/Progression/Key/Duration + transposition, H/B, enharmonics + golden/error tests |
| G5 | Knowledge/Skill | V6.x Library + erste Music Skill | valide Quellenregistry, Rechtefilter, Konzept-/Quellenlinks, plausible Evalfälle mit Quellenbelegen |
| G6 | Music MVP Integration | Shell + Domain + Knowledge | Chord Editor + Progression Explore/Explain + Save/Load/Undo in Steps-Datenordner, Accessibility |
| G7 | Drum & MIDI | G4/G6 stabil | grid/tick timing, SMF Export/Import-Gegenprobe, tempo/meta, Grenzen und audio optional |
| G8 | Plattform-Release Candidate | alle vorigen Gates | native Windows/macOS/Linux, Paket-Hashes, Lizenz-/SBOM-/Data-Privacy, manueller Abnahmeplan |

## Parallelarbeit nach Abhängigkeiten

Während **G0** allein in Glide durch Copilot bearbeitet wird, dürfen andere Agenten isoliert **G1-Research/Dokumentation, Architektur-RFC und Musikdomain-Golden-Tests als reine Skizzen** erstellen, ohne Glide-Code oder `main` zu schreiben. **G2** kann erst nach realer Glide-Basis in einen Implementierungsbranch übergehen; **G4/G5** können technisch parallel zum Shell-Schnitt entstehen, sofern die Port-/Schema-Verträge eingefroren und jeder Agent in separatem Branch arbeitet. **G7** braucht verbindliche Duration-/Tick- und Persistence-Semantik.

## Epics und Deliverables

**E-00** Baseline/CI/Regression; **E-01** Shared-Core-Vertrag; **E-02** Shell/Sidebar; **E-03** Brand/Theme/Settings; **E-04** Domain/Theorie; **E-05** Progression-Editor; **E-06** Drum Sequencer; **E-07** Knowledge Registry/Skill; **E-08** MIDI Export; **E-09** Data safety; **E-10** QA cross-platform; **E-11** Packaging/Release. Jeder Epic hat einen Hauptverantwortlichen, Ausgangs-SHA, NFRs, Testmatrix und Review/Übergabe.

## Definition of Done für jede Phase

Ein PR nur mit betroffenen Dateien, erfasster aktueller Basis und vorab dokumentiertem Verhalten; keine unerwarteten Daten- oder Asset-Verluste; Tests incl. rot/grün Gegenprobe, syntaktische und statische Checks, Trace auf Anforderungen und fachlich zuständige Dokumente; alle Skips/Nichtläufe ausdrücklich; geänderte Build-/Migrations-/Dokumentationspfade und User-Datenschutz bewertet. Menschliche Freigabe ist ein **separates** Feld. Ein Agent darf nicht selbst mergen, taggen, veröffentlichen oder destruktiv bereinigen.
