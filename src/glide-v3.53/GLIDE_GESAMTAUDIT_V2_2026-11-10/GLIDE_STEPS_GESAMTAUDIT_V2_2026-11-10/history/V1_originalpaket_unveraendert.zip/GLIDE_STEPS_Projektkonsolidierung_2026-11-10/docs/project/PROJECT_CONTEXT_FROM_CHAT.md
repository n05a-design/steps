# Projektinterne Gesprächsübergabe — 10.11.2026

**Quelle:** ausdrückliche Angaben des Auftraggebers in der aktuellen Unterhaltung. **Status:** Anforderungsaufnahme; kein externer Implementierungs- oder Prüfbeleg. Diese Datei dient als stabile Projektgedächtnis-Quelle und wiederholt keine technischen Katalogtabellen.

## Projekte

**Glide:** unabhängige Python-/Tkinter-Desktop-Anwendung für Projekte, Aufgaben, Tagesplanung, Pinnwände, Pixelzeichnungen, Notizen und Seiten; offline-first und lokal kontrollierte Daten. Aktuell wird die Oberfläche von Copilot im VS-Code-Umfeld auf 3.53 fertiggestellt; der Stand soll *erst nach grüner Prüf- und Abnahmebasis* als Ausgangspunkt für neue Projekte dienen.

**Steps:** eigenständige, quelloffene Musik-App für Akkord- und Drum-Progressionen, Harmonieerkundung, MIDI-Export und Musiktheorie. Das bestehende Steps-Repository und die über Wochen zusammengestellten Bücher, Quellen, konkurrierenden Produkte, Beispiele, Kurse, Recherche- und Forschungsdokumente sollen als nachvollziehbare Grundlage dienen. Es ist kein einfaches Umbenennen von Glide.

## Kernanforderung an die Abzweigung

- Bestehendes Glide-Desktop-**Grundgerüst** mit äußerer Oberfläche, Logo-Platz, Ansichtstitel, Symbol-/Textbuttons, Such-/Eingabeplätzen, Einstellungen, Prozess-/Fenstermechanik, Fonts, Designregeln, Accessibility und schriftlich nachvollziehbaren Entscheidungen erhalten.
- Genau **zwei zentrale Arbeitsflächen** als neutrale Inhaltshosts freistellen; bestehende Task-/Planungs-/Listen-/Notiz-/Zeichen-Features sollen **nicht** als verborgene Abhängigkeit mitgeschleppt werden.
- Seitenliste/Navigation als visuelle und interaktive *Shell-Fähigkeit* erhalten, aber die bisherigen fachlichen Listenfunktionen durch neue Steps-Ziele ersetzen. Aus- und Einklappen, Sichtbarkeit, Breiten-/Fokus- und Zustandstransitionen behalten.
- Einstellungen, Schriftfamilien, Theme, Layout, Suchfeld, Kopf, Branding und Bedienmuster nicht neu erfinden; Produkttexte und Datenpfade für Steps sauber trennen.
- Basisänderungen künftig modular und nachvollziehbar in mehreren Produkten übernehmen können, ohne jedes Mal eine monolithische Anwendung neu zu forken.
- Über alle weiteren Entwicklungsphasen die Trennung Shell / gemeinsame Systembausteine / projektspezifische Domäne **verbindlich beibehalten**.

## Planung und Werkzeuge

Der Auftraggeber nutzt zwei ChatGPT-Accounts, Claude, Gemini/Antigravity und GitHub Copilot in VS Code. Zum Zeitpunkt der Anfrage waren bis Mittwoch (ChatGPT) beziehungsweise Donnerstag (Claude) die üblichen Kontingente aufgebraucht; Copilot dient aktuell dem Glide-Abschluss. Ein gesondertes, zeitlich begrenztes Claude-„Fable 5.2“-Guthaben wird berichtet, soll nach Wiederverfügbarkeit für die Steps-Abzweigung genutzt werden. Es gibt keinen Auftrag, laufenden Glide-Code jetzt zu verändern oder Vorhaben vorzeitig zu veröffentlichen.

## Dokumentations- und Ergebniswunsch

Konsolidierte Projekt-Overview, Widersprüche, Lücken, Duplikate ohne Wissensverlust, modulare Architektur, Roadmap, Risiken und Möglichkeiten, klare Agent-Prompts je Teilgebiet. Dokumentation möglichst direkt auf GitHub; alternativ ein herunterladbares Paket. Alle bereits recherchierten Quellen sollen über Index/Provenienz angeschlossen werden; unzugängliche Quellen ausdrücklich als offen kennzeichnen. Kein stillschweigendes Löschen von Originalen oder historischer Test-Evidenz.

## Interpretationen – noch nicht als Entscheidung freigegeben

`Zwei Fenster` wird zur kontrollierten Erstplanung als „zwei dynamisch bestückbare zentrale Arbeitsflächen“ ausgelegt. Ob sie gleichzeitig nebeneinander stehen, ob man sie austauscht, ob eine Fläche ein `Toplevel` sein darf oder wie sie bei engem Fenster reagieren, wird in einem UX-Abnahmetermin konkretisiert. Bis dahin nur minimal und reversibel implementieren.
