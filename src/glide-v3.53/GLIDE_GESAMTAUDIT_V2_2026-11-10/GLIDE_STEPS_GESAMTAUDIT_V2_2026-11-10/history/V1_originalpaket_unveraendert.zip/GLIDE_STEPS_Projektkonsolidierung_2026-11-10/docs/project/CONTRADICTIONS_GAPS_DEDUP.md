# Widerspruchs-, Lücken- und Deduplizierungsregister

**Methode:** Original-Behauptung, aktuelle Evidenz, Konsequenz und Arbeitsmaßnahme getrennt; keinerlei Dateien unbesehen löschen. IDs bleiben referenzierbar.

## A. Widersprüche / divergierende Stände

| ID | Konflikt | Beleg / Interpretation | Auswirkung | Abgleich |
|---|---|---|---|---|
| C01 | Glide-Übergabe 10.11 nennt `main=3.50.7` und `3.53` lokalen Kandidaten | GitHub `main` `9e767bea5e21063466a28ac3a679406484ad5d5f` enthält tatsächlich `VERSION=3.53.0`. Übergabe ist ein **älterer Snapshot**. | Frühere QA-/Release-Gates nicht mit aktuellem HEAD verwechseln. | Laufende CI und neue QA-Matrix dieses SHA prüfen; Übergabe-Datum präzisieren, Historie bewahren. |
| C02 | Version 3.53 „läuft grün“ vs. vollständige Release-Freigabe | QA belegt 130/131 Windows-Schritte; 1 Sichtprüfung ausgelassen, andere Plattformgates offen, `release_ready=false`. Letzter beobachteter GitHub-Prüflauf war noch aktiv. | Abzweigung ohne eingefrorene Vollbasis kann Fehler übernehmen. | G0 muss sämtliche spezifizierten Prüfungen am gleichen SHA nachweisen. |
| C03 | Excel vom 07.11 als Modulübersicht vs. System V1.15 | Excel: 127 Featurezeilen, 22 Pakete, 304 Testdateien; Glide-System: 147 Featureeinträge, 25 Pakete, 311 Test-/Werkzeugdateien. | Fehlende B23–B25 und technische Fähigkeiten bei Portierung. | Excel als historisches Inventar, V1.15 als einzige aktuelle technische Autorität. |
| C04 | „Steps noch nicht angelegt“ in früherer Glide-Übernahmebeschreibung | Steps HEAD `75329fef46878a5ac816cef3690e612a9e8fe52c` existiert, inklusive Architektur-Scaffold und archivierter Forschung. | Doppelarbeit, unnötige Scaffold-Neuanlage. | Historische Aussage datieren; aktuelle Steps-Pfade als Bestand behandeln. |
| C05 | Schritte aus Excel referenzieren `Step, Checkliste, Flow/Unteraufgabe` | Historische Todo-Aufgabensprache widerspricht Steps-Musikmodell (Chord/Drum Progression). | Risiko eines falschen Produkt-Datenmodells. | S08 u. ähnliche Einträge als Fremd-/Altprodukt prüfen und für musikalisches MVP ersetzen; Original behalten. |
| C06 | „2 Fenster“ ohne technischen Vertrag | Könnte 2 Arbeitsbereiche oder 2 OS-Toplevels bedeuten. | Fokus-, Mehrmonitor-, Speicher-, Lebenszyklus- und Layoutänderungen. | Vor Implementierung UX-Entscheidung; bis dahin nur neutrale 2-Slot-Shell planen. |
| C07 | Großes V6.6/V6.7-Produktionsarchiv vs. schlankes Harmony-MVP | 49 und andere gezählte Hauptordner, doppelte Bereichsnummern 21/39, heterogene Vollproduktionsrecherche. | Fehlgeleitete Scope-Ausweitung bis zur DAW. | Forschung archivieren, Harmony/Drums priorisieren, Definitionsumfang in ADR trennen. |
| C08 | Ältere Steps-Rückbau-Dokumente enthalten teils 2 parallele Domain-Pfade | Aktuelle Steps-Architektur legt `src/steps/` als reine Domain und `app/` als GUI fest. | Inkonsistente Imports/Duplizierung. | Eine Domain-Engine `src/steps`, keine zweite `app/theory`. |
| C09 | Alter Steps-Repolauf `ANALYSE_REPOSITORY.md` mit 1.827 Dateien und „push:false“ | Neuer HEAD wurde mit 1.931 Dateien inventarisiert; die aktuell verwendete Verbindung hat Push-Rechte. | Veraltete Bestandszahlen und Zugriffsentscheidung. | Alte Befunde nur mit alter SHA zitieren; Rechte jeweils neu prüfen. |
| C10 | „MPL-2.0-Projekt“ vs. sichtbare fremde Assets | Zwei Repo-LICENSE-Dateien sind MPL-2.0; Dritt-PDFs/Screenshots/HTML/MIDI unterliegen möglichen eigenen Rechten. | Rechtliches Veröffentlichungsrisiko; Git-Historie bleibt trotz Löschen zugänglich. | Dateien/Metadaten einzeln rights-reviewen; ohne Rechtsstatus nicht weiter kopieren. |
| C11 | Steps README/`SKILL.md` vs. erwartete vollständige Projektdokumentation/Knowledge Base | Root README nur 2 Zeilen mit `&amp;`, `SKILL.md` nur Workflow, source registry praktisch leer; Harmony-Skill-Referenzen sind kurze Starttexte. | Agent ohne ausreichenden faktenbasierten Kontext. | README als Navigationshub, Registry füllen, skill evaluating, cite-only evidence. |
| C12 | Technisch entkoppelt, da 88/94 Dateien ohne Tk-Import | Direkte Importfreiheit beweist keine Daten-/Pfad-/UI-Kopplungsfreiheit; `app.pyw` bleibt monolithisch. | Importseiteneffekte, kaputte Defaults und gemeinsame Datenrisiken. | Vertragliche Integrationstests mit isoliertem `RuntimePaths` und tatsächlichem Tk-Host. |
| C13 | Historische 3.53-Tempo-Rotläufe vs. finaler Windows-Volltest | Derselbe QA-Bericht erhält beide mit eigener Test-ID; finaler Lauf bestand die beiden Performancefälle. | Red/Green nicht durch „Wiederholen bis grün“ umdeuten. | Red-Befunde historisch als Stabilitätsrisiken, finalen Erfolg dem konkreten SHA/Lauf zuordnen. |
| C14 | Projektkonsolidierung nennt sechs Originale; Archiv kann nur fünf belegen | Dokument `Glide Kontext für Fable(2).md` fehlte als Original im geprüften Zustand. | Behauptete lückenlose Ursprungsbelege unsicher. | Original nachreichen oder Quellenlücke beibehalten; nicht aus Sekundärtext erfinden. |

## B. Priorisierte Lücken

| ID | Prio | Fehlender Nachweis / Entscheidung | Fertig bei |
|---|---|---|---|
| G01 | Blocker | Gleicher Glide-SHA über Windows/Linux/macOS, native Paket-/Startprüfungen, vollständige manuelle UI/DPI-Matrix | Quellstand-/Runtime-/Hashprotokolle in QA und explizite Freigabe |
| G02 | Blocker | Importseiteneffekte `app.pyw` (WA49), Tk-Host-/Settings-Initialisierung | Import außerhalb echter Userdaten mit kontrollierten Pfaden/Mockports und Lifecycle-Test |
| G03 | Blocker | Exaktes Verhalten der zwei Arbeitsflächen / Nebenansicht | akzeptierte UI-Zustandsmatrix einschließlich klein/groß, hidden und keyboard |
| G04 | Hoch | Welche B01–B25 tatsächlich in Steps benötigt werden | dependency graph, Lizenz-/Ressourcenzuordnung, Ports, per-Paket Testentscheid |
| G05 | Hoch | Reale Produkt-/Paket-/Bundle-ID von Steps, Branding und Icon-Rechte | freigegebene Identitäten, eigene Datenpfade, keine Glide-Zugriffe |
| G06 | Blocker | Rechte- und Provenienz-Audit öffentlicher Fremd-PDFs, Webassets, MIDI, Konkurrenztexte | pro Quelldatei Lizenz/Erlaubnis/Rechtsgrundlage und Public/Private-Policy |
| G07 | Hoch | Korrekte Musiknotation/Enharmonik, Context-Harmony, Durations/Drum Patterns | schemas + golden tests + fachlicher Review |
| G08 | Hoch | Quelle / Rechte / Snapshot-Hashes für V6.6/V6.7 und die zwei 21-/39-Doppelbereiche | kanonische Alias-/Mapping-Tabelle, referential integrity, keine unique data verloren |
| G09 | Mittel | Doppelte und kaputte historische Link-/Index-/Hashes nach Repo-Reorganisation | maschineller Linkcheck & aktuell rekonstruierter SHA256-Index |
| G10 | Hoch | Tests für Kern-UI mit Task-Domain vollständig entkoppelt | realer Windows/Linux/macOS UI-Start + 2-Pane-Interactionmatrix |
| G11 | Hoch | Skills-Qualitätsprüfung und Importtauglichkeit der Knowledge-Referenzen | zitatbasierte eval-sets, Negative/Contradiction-Tests, getrennte Skill-Version |
| G12 | Mittel | Reale MIDI-/Playback-Engine und Arbeitsmodell | offener RFC/ADR, Testfixtures, Export-Import-Roundtrip, optionaler Port |
| G13 | Mittel | Aktuelle Glide-3.53 Testlauf-Freigabe nach zuletzt beobachtetem `in_progress` | CI-Run-IDs und status `success`, ausdrücklich welche Gates nicht durch CI gedeckt |
| G14 | Mittel | Historisches Fable-Original und weitere Library-Rohdateien | identifizierter Originalpfad/Hash oder bewusst `unavailable` |

## C. Deduplikation ohne Informationsverlust

**In dieser Übergabe konsolidiert:** Wiederholte Claims über Zielbild, Shell-Erhalt, Plattformen, Knowledge/Skill, Roadmap und KI-Tools werden nur einmal in der Projekt-Overview erklärt und von allen Prompts **verlinkt**, statt an abweichenden Stellen nochmals als eigene Wahrheit gepflegt.

**Nicht automatisch entfernt:** Historische Dateiversionen, PDFs, 3.53 Rotläufe, ursprüngliche Quellzitate, CSV-/JSON-Manifestdaten, Rechte-/Lizenzhinweise, Screenshots, alte Branches, Cache-Artefakte und binäre Dubletten. Schon identische SHA-256-Blobs können aus Provenienzgründen andere Pfadrollen haben. Historischer Steps-Audit nennt 160 identische Gruppen/426 zusätzliche Pfade auf **seiner alten SHA**, nicht als heutige Messung.

**Vorgeschlagene Prozedur:** (1) volle SHA256-Inventur mit Root/HEAD; (2) exakte Hash-Duplikate und nur textuell ähnliche Aussagen unterscheiden; (3) Rolle/Herkunft/Versionslinie/Referenzen erfassen; (4) kanonisches Dokument pro Thema bestimmen; (5) alias-links und Änderungslog; (6) erst nach Human-Review in eigenem PR konsolidieren; (7) unersetzliche Historie und Aussagen bewahren; (8) keine automatische Git-Historienbereinigung.
