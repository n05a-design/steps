# Technischer Vertrag: wiederverwendbarer Desktop Core

**Status PROPOSED — zu implementieren nur nach Glide-Gate und Architekturfreigabe.**

## Schichten und Importregel

`product_domain` darf `appkit` nicht benötigen. `appkit` darf keine Glide-/Steps-Domain importieren. `product_ui` importiert `appkit` und Produkt-Domain über Ports. `platform_adapters` kapselt Tk/OS/Dateisystem. `test_fixtures` bleiben datenisoliert. Zyklische Imports, direkte Imports des Glide-`app.pyw` als Bibliothek und globale Singleton-Modelle sind verboten.

## Vorgeschlagene öffentliche Schnittstellen

| Vertrag | Wesentliche Felder / Operationen | Nicht erlaubte Annahmen |
|---|---|---|
| `AppIdentity` | `app_id`, `display_name`, `version`, `icon_ref`, `extensions`, `org` | keine Glide-Defaultidentität in Steps |
| `RuntimePaths` | `data`, `cache`, `log`, `lock`, `backups`, `recovery`, `temp`, `resources` | kein Modulimport legt Ordner an oder liest Glide-Daten |
| `ThemeProvider` | `tokens`, `font_style`, `font_weight`, `size_scale`, `subscribe/unsubscribe` | UI-Rollen statt hardcodierter „lila“-/Tk-Farben |
| `WindowState` | normal/compact, geometry, DPI/monitor, focus, split ratio | kein `update()` in rekursivem Tk-Layout-Callback |
| `NavigationProvider` | `NavigationItem(id, title, icon, enabled, category)`, `activate(id)`, selection, `dispose()` | keine Task-/List-Kind-/Folder-ID-Kopplung |
| `CommandRegistry` | eindeutige Action-ID, enabled + reason, callback, shortcut, icon, undo policy | keine zweite Befehlslogik in Kopf/Menu/Palette |
| `WorkspaceHost` | `mount_primary(view)`, `mount_secondary(view)`, `replace`, `hide/show`, `dispose` | keine Widget-Referenzen nach `destroy()` behalten |
| `SettingsStore` | schema version, `load`, `validate`, `save_atomic`, migrations | keine stillen unbekannten Feldverluste |
| `DocumentStore[T]` | snapshots, version, read, commit, backup, restore, lock, error | keine App-Domain-Daten im Core-Vertrag |
| `UndoController` | idempotente commands, stable IDs, group/rollback, dirty | keine Mutationen an geteilten Objekten außerhalb vorgesehenen Pfads |
| `EventBus` | scoped publish, subscribe + unsubscribe on teardown | keine Zombie-Callbacks / interleaved GUI-thread writes |
| `Diagnostics` | structured event + context, failure classification, user privacy | keine echten Dateipfade/Passwörter in Repo-Testlogs |

## Lifecycle und Tk-Hardening

`create config → validate paths → acquire lock → load settings/data → create Tk root → mount shell → attach product views → enable actions → run mainloop → stop callbacks/workers → flush pending editors → persist or report failure → release lock → dispose`. Der tatsächliche Reihenfolgebeweis muss in Testfällen erbracht werden. UI-Aufrufe ausschließlich im Tk-Hauptthread. Worker senden Ergebnisse per thread-sicherem Queue und vom Tk-Hauptthread periodisch verarbeiteten Events; `after`-IDs bei Widget-/App-Ende cancellieren; nicht auf zerstörten Root warten. Focus, Escape, `Toplevel`, Mac Menus, DPI, Multiple Monitors und Callback-Reentrancy jeweils separat testen.

## Datenintegrität

Zwei Produktdatenräume (`glide` und `steps`) dürfen niemals denselben Datenordner/Lock/Backup im Standard verwenden. Testläufe müssen ein eigenes temporäres `data_dir` erzwingen. Atomarer Write + fsync soweit verfügbar + Snapshot/Backup + Restore-Test; Fehler unterscheiden „vor Commit“ / „nach Commit“. Schema-Migrationen brauchen Versionierung, Fixture-Katalog, Rollback und ältere App liest unbekannte höhere Version nicht schreibend. Kein Netzwerk-/Account-Start als neue Core-Abhängigkeit.

## Synchronisierung zwischen Produkten

**Keine automatische Copy-Paste-Propagation.** Jede Core-Änderung benötigt einen eigenen versionierten Core-Commit, Changelog und API-Compatibility-Note sowie zwei Integrations-PRs in Glide/Steps mit Regression und Abnahme. Vorher ist es ein lokaler Versuchsadapter und bleibt privat, nicht als „Framework v1“ vermarkten. SemVer nur nach klarer API-Landschaft, vorher SHA-Fixierung. Verteilte Plattformtests pro Zielprodukt.

## Wartungsregeln

Einziger Katalog für Glide weiter in `src/glide/README.md`, kein Parallelregister. Erst nach Freigabe ist das Core-API in `docs/architecture/SHARED_CORE_CONTRACT.md` kanonisch. Veraltete Deps/Imports und weitergegebene Ressourcen nachvollziehbar mappen. Jede neue Featurearbeit muss „Core oder Domain?“ sowie zuständigen Lifecycle-/State-Eigentümer im PR nennen.
