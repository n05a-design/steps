# Decision Register — bestehende Entscheidungen und noch offene ADRs

| ID | Status | Inhalt | Autorität / Freigabegrenze |
|---|---|---|---|
| D-01 | CONFIRMED | Glide bleibt eigenständiger offline-first Desktopplaner mit lokalen Nutzerdaten. | Auftraggeber / Glide AGENTS |
| D-02 | CONFIRMED | Steps ist eigenständiges Open-Source-Musikprojekt mit Harmonie-/Chord-/Drum-Progession-Zielen. | Auftraggeber / Steps AGENTS |
| D-03 | CONFIRMED | Glide 3.53 erst nach belastbarer grüner Basis als Ableitungsquelle verwenden. | Auftraggeber; Gate G0 offen |
| D-04 | CONFIRMED | Äußere Glide-Chrome, einklappbare/hideable Sidebar, Settings, Branding-Pipeline, Fonts, Theme, Interaktionen und Dokumentationsregeln erhalten; Business-Inhalt entfernen. | Auftraggeber; technisch noch offen |
| D-05 | CONFIRMED | Änderungen am gemeinsamen Kern müssen künftig modulweise und nachprüfbar übertragbar sein. | Auftraggeber; kein Framework freigegeben |
| D-06 | CONFIRMED | Keine Duplikatbereinigung zulasten einzigartiger Informationen und Quellen. | Auftraggeber / Steps AGENTS |
| D-07 | EXISTING | Glide V1.15 listet B01–B25; `src/steps` ist die reine Domain-Baseline. | GitHub-Snapshots; nicht gleich Bibliotheksfreigabe |
| A-01 | PROPOSED | „Zwei Fenster“ zunächst als ein Hauptfenster mit zwei Inhalts-Slots realisieren. | UX/ADR erforderlich |
| A-02 | PROPOSED | Gemeinsamen Core über explizite Ports extrahieren, erst nach zwei Produkt-Integrationen extern versionieren. | Architektur-ADR erforderlich |
| A-03 | PROPOSED | MIDI nach erstem gültigen Fortschritts-/Takt-/Dauermodell realisieren, Audio-Preview später. | Produkt-Scope-ADR |
| A-04 | PROPOSED | Wissens-Skill als dünnen Agentenworkflow über versionierten, belegten Concepts statt als Volltextablage. | Knowledge-Governance-ADR |
| A-05 | DEFERRED | Große Ableton-/Mixing-/Mastering-/Distribution-Domäne nicht in ersten Steps-MVP aufnehmen. | Produktumfang vor MVP festlegen |
| A-06 | UNKNOWN | Ob Shell-Paket separat, im Steps-Repo oder in gemeinsamer Monorepo entwickelt wird. | Versionierungs-/Release-ADR |
| A-07 | UNKNOWN | Eigene Steps App/Bundle-ID, Datendateiendung, UI-Logo, Exportformat und Semantik „Suchen“. | Freigabe nach Prototyp |
| A-08 | BLOCKED | Quellrechte für öffentlich vorhandene Research-PDFs und Drittanbieterassets. | Eigentümer/Rechteprüfung nötig |

**Regel:** Agenten erstellen ADR-Vorschläge mit Optionen, Kosten, Risiken, Migration, Alternativen; sie markieren keinen Vorschlag eigenmächtig `accepted`. Historische Glide D01–D77 bleiben in `docs/ARBEITSRICHTUNG.md`; dieses Register ersetzt sie nicht und übersetzt sie nicht pauschal auf Steps.
