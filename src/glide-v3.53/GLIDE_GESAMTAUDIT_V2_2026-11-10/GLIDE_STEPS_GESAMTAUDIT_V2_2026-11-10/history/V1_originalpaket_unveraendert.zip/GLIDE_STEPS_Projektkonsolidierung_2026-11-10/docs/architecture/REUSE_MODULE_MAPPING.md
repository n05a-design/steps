# Wiederverwendungsplan auf Baustein- und Modulniveau

**Autorität für Vollständigkeit:** Glide `src/glide/README.md` System V1.15, Abschnitte 1–3 und 9. Die folgenden Zeilen sind eine **abgeleitete priorisierte Auswahl**, kein neues kanonisches 94-Dateien-Inventar.

| Paket | Primärmodule / Bereich | Steps-Relevanz | Übernahmeregel |
|---|---|---|---|
| B01 Theme & Design | `appearance`,`ui_design`,`font_catalog`,`backdrop` | P0 | Theme-Tokens vom Tk-Host trennen, Ressourcen und Rollen testen |
| B02 Branding | `brand`,`logo`,`logo_raster`,`svg_geometry` | P0 | Logo-Engine parametrisieren, eigenes Steps-Logo; `svg_geometry`→`brand` Importgrenze korrigieren |
| B03 Window | `compact_mode`,`app.pyw`-Fensterteile | P0 | pure Geometrie isolieren; window/focus lifecycle statt `ListApp`-Bindung |
| B04 Navigation | `sidebar_policy`,`side_view`,`action_menu` | P0 | **nicht** `pages/lists/notes/drawings` und Task-IDs übernehmen; Navigation-Port |
| B05 Persistence | `persistence`,`save_result`,`data_lock`,`session_guard` | P0 | generischer atomarer Commit, Produkt-Schema/Lock/Paths injizieren |
| B06 Backup | `backup_catalog`,`backup_snapshot`,`schema_backups` | P1 | kein Glide-Datenformat in Steps, Restore-Tests |
| B07 Exchange | `notion_archive`,`markdown_tree`,`exchange_patch` | optional | sichere Parserschnittstellen einzeln; Notion-Aufgaben kein Steps-MVP |
| B08 Media | `image_conversion`,`image_preview`,`animation_export` | optional | Tk-Bildhost/Worker/OS-Abhängigkeit prüfen |
| B09 Accessibility | `accessibility`,`accessibility_bindings`,`glyph_metrics` | P0 | UI-Rollen und native Widgets, Screenreader manuell nachweisen |
| B10 QA/Release | `tests/tools`,`packaging`,`scripts/pflege` | P0 | Pfade, Bundle-ID, Pip-Abhängigkeiten, CI/Build-Ziele produktneutral parametrieren |
| B11 Task Planning | `planning`,`day_relief`,`week_planning`,`day_proposal` | **nein** | Glide-Domäne verbleibt dort |
| B12 Time & Focus | `focus_timer`,`occupied_time`,`calendar_service` | optional | BPM/Beat-Time ist **keine** Kalender-/Task-Zeit; nicht versehentlich kopieren |
| B13 Search/Commands | `content_search`,`action_catalog`,`interaction_policy` | P1 | ein CommandRegistry, SearchProvider mit Steps-Ergebnistyp |
| B14 ICS/Timezone | `ics_busy`,`ics_recurrence`,`ics_timezone`,`repeat_ics`,`timezones` | **nein** | nicht für Musik-Zeitmaß verwenden |
| B15 Rich Text | `page_markdown`,`page_features`,`markdown_tree` | optional | eigener Steps-Wissensartikel, kein Glide-Block-/Task-Schema |
| B16 Undo/Mutation | `task_editing`,`undo_history`,`structural_guard`,`editor_flush` | P0/P1 | fachfreie Transaktionen, stabile IDs, Flush und Undo; nicht Task-Commands übernehmen |
| B17 Attachment | `attachment_paths`,`attachment_policy`,`restore_assets`,`page_restore` | P1 | verifizierte Ressourcen-/MIDI-Importe, Path-Traversal/Backup/Restore |
| B18 Home Widgets | `home_dashboard`,`home_tiles`,`home_task_tiles` | optional | nur UI/Projection-Prinzip, keine Task-Dashboards |
| B19 Sidebar/Secondary | `sidebar_policy`,`side_view`,`view_definition` | P0 | 2-Slot-Host mit fokussicherem Lifecycle, neue Navigationstypen |
| B20 Pixel Drawing | `drawing`,`drawing_image`,`animation`,`animation_export` | DEFER | Glide-spezifisches Feature; keine Steps-Kernlast |
| B21 Debug/Health | `runtime_diagnostics`,`storage_health`,`load_phases` | P0 | privacy safe, fehlersichere Lifecycle-Reaktionen |
| B22 Notion adapter | `notion_archive`,`notion_import`,`notion_reimport`,`notion_hierarchy` | DEFER | fachfremde Produktintegration |
| B23 Governance | `AGENTS`, `DESIGN_RICHTLINIEN`, `DOKUMENTENPFLEGE`, QA | P0 | Prinzipien übertragen, historische Glide-D-Entscheidungen nicht als Steps-Beschluss |
| B24 Bootstrap/Settings | `runtime_check`,`glide_start`,`settings_compat`,`release_notes` | P0 | *WA49* Importseiteneffekte entfernen, RuntimePaths vor Start injizieren |
| B25 OS integration | Tk-root Dialoge/Benachrichtigungen/DnD | P1 | optional, App-ID und Drittbibliotheken, OS-Prüfmatrix |

## Kritischer Import-/Kopplungsgraph

Der reine Python-Importgraph ist nicht gleich Laufzeit-Kopplungsgraph. Bei jeder Kandidatendatei sind mindestens zu prüfen: `import`/`from` inkl. dynamisch; globale Konstanten und Modulinitialisierer; `__main__`-/`app.pyw`-Aufrufe; Umgebungsvariablen/WorkingDirectory; Daten-/Schema-IDs; `Tk`-Objekte/Interpreter; Ressourcenpfade/Fonts/SVGs; Home-/Task-ViewModels; Fehler-/Backup-/Lock-Mutationen; Logging personenbezogener Pfade; Test-Fixtures; Lizenz- und Third-Party-BOM.

## Konsistente Update-Strecke

1. Kandidat hat einen Verantwortlichen, Quell-SHA und Integritätsmanifest.
2. Ein kleines Modul oder Port wird isoliert und mit `glide`-Dummy/Steps-Dummy getestet.
3. Code fällt nicht auf globales `ListApp` oder implizite Dateien zurück.
4. Produktverhalten in Glide gegen *identische* Testfixtures vor/nach geprüft.
5. Steps bekommt eigene Package-/Data-IDs und positive sowie negative Regressionen.
6. Bei zwei grünen Produkt-Integrationen kann die gemeinsame Library versioniert werden; PRs bleiben explizit getrennt.
