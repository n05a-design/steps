# Projekt-Overview — Glide-Core als Fundament für Steps

**Evidenzstatus:** Synthese aus dokumentierten Anforderungen, dem Glide-/Steps-GitHub-Bestand vom 10.11.2026, der historischen Modul-Arbeitsmappe und zwei Research-Grundlagen. Vorschläge sind nicht implementiert.

## 1. Strategie und Produktabgrenzung

Glide bleibt ein eigenständiger Offline-Planer. Steps wird eine eigenständige App zur **Erstellung, Untersuchung und Vermittlung von Chord- und Drum-Progressions**. Gemeinsame Ebene ist nur die technische Desktop-Infrastruktur: Fenster-/Layoutkoordinator, Theme/Branding, Navigation, UI-Komponenten, Input-Aktionen, persistente Settings, Diagnostik, Barrierefreiheit und Qualitätssicherung. Musiktheorie gehört nicht in Glide-Core, Aufgabenplanung nicht in Steps-Core.

```text
                          VERSIONIERTE VERTRÄGE, KEINE GLOBALE KOPIE
        ┌───────────────────────────────────────────────────────────────┐
        │ Shared Desktop Core / AppKit (künftig nach Isolation freigeben)│
        │ Root · Chrome · Theme · Sidebar · Commands · Slots · Settings│
        │ RuntimePaths · Lifecycle · Diagnostics · A11y · Tests        │
        └──────────┬───────────────────────────────────┬────────────────┘
                   │ Ports / Adapter                   │ Ports / Adapter
        ┌──────────▼─────────┐              ┌──────────▼───────────┐
        │ Glide / Tasks      │              │ Steps / Music        │
        │ Tasks / Kalender   │              │ Theory / Progression │
        │ Pinnwand / Pixel   │              │ Drum / MIDI / Coach  │
        │ Glide-Datenschema  │              │ Steps-Datenschema    │
        └────────────────────┘              └──────────────────────┘
```

## 2. Existierender Bestand

**Glide HEAD:** `9e767bea5e21063466a28ac3a679406484ad5d5f`, `VERSION 3.53.0`, `GLIDE_SYSTEM_VERSION 1.15`. Das einzige kanonische Systemregister dokumentiert **94 Quellen (93 Runtime + 1 Prototyp), 147 Features, 25 Wiederverwendungs-Kandidaten und 311 Test-/Werkzeugdateien**. Die modulen Fachteile sind größtenteils Tk-frei, die Start-/UI-/Dialogsteuerung in `app.pyw` ist jedoch noch erheblich verflochten. Ein „fertiges wiederverwendbares Framework“ ist **nicht** belegt. [Original](https://github.com/n05a-design/glide-to-do/blob/9e767bea5e21063466a28ac3a679406484ad5d5f/01_Repository/Glide/src/glide/README.md).

**Steps HEAD:** `75329fef46878a5ac816cef3690e612a9e8fe52c`, `0.0.0-dev`: vorbereitet sind `src/steps/`, `app/`, `knowledge/`, `research/`, `design/`, `schemas/`, `decisions/`, `skills/`, `tests/` und die historisch umfangreiche Bibliothek. Die READMEs der Fachmodule sind *Platzhalter*. Eine ausführbare Steps-Anwendung, getestete MIDI-Pipeline oder gefüllte Provenienz-Registry sind nicht belegt. Das vorhandene `music-harmony-coach`-Skill ist ein erster Ablaufrahmen mit kurzen Referenzen, noch keine vollständig verifizierte Wissens-Engine. [Architektur](https://github.com/n05a-design/steps/blob/75329fef46878a5ac816cef3690e612a9e8fe52c/docs/architecture/architecture.md), [Skill](https://github.com/n05a-design/steps/blob/75329fef46878a5ac816cef3690e612a9e8fe52c/SKILL.md).

## 3. Was aus Glide erhalten bleiben soll

Die gesamte sichtbare App-**Chrome außerhalb der zwei inneren Arbeitsflächen**: Fensterkopf mit Logo-/Titel-/Unterzeilen-Rollen, Themenfarben und Schriftwahl, Kopfbuttons/Symbolpolitik, Menüs, Status- und Fehlerkommunikation, Einstellungen, Sidebar, Navigation, Zeilen-/Hover-/Focus-Zustände, Seitenleiste ausblendbar/einklappbar, kompakter Modus soweit verfügbar, Eingabe-/Suchfeld als generischer Host, Layout/Geometrie, Tastatur, Barrierefreiheit und OS-bezogene Ports. **Erhalt des visuellen Ortes ≠ Erhalt des bisherigen fachlichen Verhaltens**; neue App-Commands werden ausdrücklich neu gebunden.

## 4. Was nicht in den generischen Kern gehört

Task-Mutationen, Aufgabenliste, Fälligkeit, Wiederholung, Eisenhower, Zeiterfassung, spezifische Home-Kacheln, Kalender-/ICS-Logik, Notion-Aufgabenhierarchie, Kanban/Pinnwand, Pixel-Editor, Seiten-Markdown-Daten, Glide-Schema, `ListApp`-geführte globale Zustandsfelder, alte Produktstrings, Glide-Markengrafiken und produktgebundene Sicherungen. Diese Funktionen können als unabhängige Glide-Features weiterbestehen, aber **nicht** in Steps geladen oder bei der Shell-Kopie stillschweigend mitimportiert werden.

## 5. Schritte zur sauberen 2-Flächen-Shell

- **Zielbild:** Eine Tk-Hauptanwendung mit unverändertem äußeren Chrome plus zwei ausdrücklich benannten Slots `primary` und `secondary`. Sekundär darf ein-/ausgeschaltet und ggf. platzsparend dargestellt werden; keine zwei unabhängigen Datenzustände.
- **Sidebar:** bestehende Zustände (sichtbar, reduziert, eingeklappt, ausgeblendet) und Übergänge sind Shell-Sache; die alten vier Glide-Sektionen (`pages/lists/notes/drawings`) und deren Regeln sind **kein** universeller Vertrag. `NavigationItem(id,label,icon,enabled,target)` anstelle von Task-/List-Datenobjekten.
- **Auswählen:** Platzhalter führen nicht ins Nichts. Noch nicht implementierte Ziele erhalten `disabled + Erklärung` oder erlaubte neutrale Demoansichten ohne Schreibaktionen.
- **Eingaben:** Suchfeld wird über einen projektspezifischen Search-Port mit Provider/Result-Target versorgt; ohne Provider nur bewusst neutraler `disabled`-Zustand. Einstellungen und Schrift-/Themewechsel funktionieren bereits in der Shell.
- **Branding:** wiederverwendbare Logo-Pipeline / SVG-Parser, aber eigenes Steps-Zeichen und eigene Identität; keine Umbenennung alter Glide-Archivbelege.
- **Zustand:** pro App isolierte Settings, Daten, Caches, Locks, Crash-/Recovery-Verzeichnisse und Testdaten. Windows/macOS/Linux; keine Cloud- oder Lizenz-Scans beim Produktstart.

## 6. Steps-Funktionsbereiche und Prioritäten

| Bereich | Priorität | Definition und zentrale Abhängigkeit |
|---|---|---|
| Shell & Navigation | P0 | 2 Slots, Sidebar, Kopf, Theme/Fonts, Settings, Lifecycle, Fokus/A11y |
| Musikmodell | P0 | PitchName, Note, Interval, Scale, Chord, Key, Progression, Duration, Pattern; klare Semantik |
| Harmonische Analyse | P0 | Akkordstufen, Kontext, alternative Analysen, DE H/B, enharmonische Schreibweise |
| Progression-Editor | P0–P1 | Erstellen, bearbeiten, duplizieren, undo, speichern, laden, transponieren, erklären |
| Lern-/Knowledge-Explorer | P1 | Begriffe, Beispiele, Quellenverweise, Konfidenz/Alternativen, Skill-Unterstützung |
| Drum Pattern | P1 | Grid/Steps, Tempo/Quantisierung, Variation, Instrument-Mapping, Tests |
| MIDI-Export | P1 | reproduzierbarer SMF-Export, Timing, Channel, Tempo, Validierung/Reimport |
| Audio-Preview | P2 | optional, stabile Events und Worker-Lifecycle, offline ohne Konto |
| Bibliothek / Skill | P0 (Governance), P1 (Inhalte) | Registry/Provenienz/License und kleine referenzierte Skill-Arbeitsanweisungen |
| Breiter Produktions-/Ableton-Stack | DEFERRED | Recherchearchiv; kein automatischer DAW-/Mixing-/Mastering-MVP |
| App-Pakete/Releases | P1 | getrennte Identität, Lizenz-/Asset-Prüfung, Windows/macOS/Linux-native QA |

## 7. Wissensbasis-Architektur

`research/` bewahrt originale, widersprüchliche und historische Forschung; `knowledge/sources/registry.yaml` identifiziert jede tatsächlich geprüfte Quelle einschließlich Lizenz, Autor, Version, URL und Datei-/Seitenbezug. `knowledge/concepts/` enthält **eigenständige, belegte Erklärungen**; `schemas/` ermöglicht maschinell prüfbare Akkorde/Progressionen; `skills/` enthält knappe Aufgabenabläufe und verweist auf Knowledge-Einträge. Ein AI-Skill ist **kein** Ersatz für Nachweise, Tests und ein eigenständiges Regelmodell. Volltexte/Fremdmedien werden nicht automatisch öffentlich übernommen.

## 8. Offene technische Architekturentscheidungen

Die dokumentierte Steps-Struktur aus `src/steps` (Domain) und `app/` (UI) bleibt gültig; **nicht** zusätzlich eine zweite Business-Engine `app/theory` schaffen. Ob Shared-Core zunächst als Package im Steps-Repo, als separates Git-Repository oder als Python-Distribution entsteht, ist bewusst **noch nicht beschlossen**: Empfehlung ist **erster funktionsfähiger Shell-Schnitt mit expliziten Ports in isolierter Ableitung, anschließende Versionierung einer Shared-Library nach zwei Client-Integrationstests**. Das verhindert verfrühtes Framework-Design und Drift.

## 9. Qualitätsprinzip

Eine neue Steps-Funktion muss in jedem Pull Request belegen: Quelle/Entscheidung, Codeverantwortung, Schemaeffekt, Fehler-/Rollbackpfad, isolierte Tests, UI-/Fokus-Zustände, Performance-Messung soweit relevant, Plattformgrenzen, Dokumentation und nachvollziehbare Abnahme. Ein grüner Glide-Workflow ist keine Steps-Freigabe. `README.md` verweist auf genau eine fachliche autoritative Stelle je Thema; keine zweiten konkurrierenden Module-/Featurelisten.

## 10. Konkreter nächster Auftrag

Zuerst den 3.53.0-Basisgate und die `B01–B25`-Abhängigkeitsklassifikation vollständig machen, dann den neutralen Shell-Adapter aus `app.pyw` schrittweise extrahieren. Das bestehende monolithische Glide erhält währenddessen keine ungenehmigten Löschungen. Die notwendigen agentenfähigen Einzelaufträge liegen unter `prompts/`.
