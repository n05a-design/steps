# Steps-Wissensbibliothek und Agent-Skill — fachliche Strategie

## Bestandsrealität

Steps hat ein breites Research-Archiv (V5.x–V6.7, Musiktheorie, Harmonielehre, Chord-/Drum-Progressions, Producing, Mixing, Mastering, Ableton, Wettbewerber, Websites, PDFs), historische Manifest-/Hashlisten, erste `knowledge/concepts/`-Platzhalter und zwei Skill-Einstiege. **Bestand an Dateien ≠ geprüfte, lizenzkonforme Knowledge Base.** `knowledge/sources/registry.yaml` ist noch nicht sinnvoll befüllt, Konzeptseiten sind zum Teil Platzhalter.

## Vorgeschlagener Workflow

1. Quellenaufnahme `SourceRecord`: ID, canonical URI, Autor/Titel/Edition, Sprache, Bereich, DOI/URL, lokaler SHA-256, Lizenz/Terms, Nutzungsrechte, Public/Private, Fundstelle, Extraktionstatus, Prüfer, Unsicherheit.
2. Rechte-Gate: eigenes Original / klar lizenziert / zitierfähig / unbekannt / gesperrt. Fremde Volltexte, Webseiten-Assets, kommerzielle MIDI-Beispiele **nicht** als public Knowledge-Text republishen. Zugriff auf lokale Originale in privater Arbeitsumgebung lässt Veröffentlichungsrechte unberührt.
3. Dedup: SHA256-Identität ≠ begriffliche Identität; Begriffsversion und Herkunft bewahren, mehrfach vertretene Aussagen auf kanonisches Konzept mit Quellverweisen normalisieren. V6.6-/V6.7-Versionen getrennt halten, Kreuzlinks prüfen.
4. Konzeptaufbereitung: Definition, Voraussetzungen, Schreibweisen, Bereich/Stil, belegte Beispiele, Gegenbeispiele, alternative Lesarten, deterministische Rechenfälle, Lernhinweise, Risiko/Unsicherheit, Quellenanker.
5. Knowledge Graph/Typed Relations: Interval–Scale–Key–Chord–Progression mit `relation_type`, Kontext, Evidenz-ID und Gültigkeitsbedingungen. Mehrdeutige Funktionsanalysen nicht weg-normalisieren.
6. Schemas/QA: originale `schemas/source,concept,chord,progression,analysis.schema.json` verwenden, nur versioniert ändern. Referential integrity, Rückverweise, Unicode/DE H-B/englisch B-Bb, Lizenzstatus, eigene Golden Cases prüfen.
7. Skill: Root `SKILL.md` ist der **Workflow-Router**, `skills/music-harmony-coach/.../SKILL.md` Facharbeitsweg, `knowledge/` kanonischer Faktenbestand. Skills halten Index/Leseanleitung statt vollständige parallele Lehrbücher. Tests prüfen retrieval relevance, fehlende Quellen, widersprüchliche Aussagen, falsche Zitation und unzulässige Wiedergabe.

## Beispiel eines Skill-Evals

**Prompt:** `Analysiere E7 → Am in C-Dur und in a-Moll und nenne alternative Deutungen.` Erwartet werden Kontexttrennung, V7/vi vs V7, mögliche Mehrdeutigkeit und belegte Quellenangaben ohne erfundene Buchseiten. **Negativtest:** „Zitiere Kapitel 7 Seite 53 des unbekannten Buches wörtlich“ → keine erfundene Quelle, keine längere geschützte Wiedergabe. **Datenfall:** „Erzeuge Chord-JSON“ → nur nach gültigem Schema und Tonbenennungssystem.

## Kein Scope-Drift

Die Sammlung zu gesamter Musikproduktion ist wertvoll als separate Forschung und späterer Unterrichtskontext, aber **nicht** Beleg, dass Steps bereits DAW, Synthesizer, Transkription oder Mixing-Produkt sein sollte. Solche Ausweitungen erfordern ADR mit Nutzerziel, Aufwand, Dependencies, Lizenz, Tests und klarer Releasestufe.
