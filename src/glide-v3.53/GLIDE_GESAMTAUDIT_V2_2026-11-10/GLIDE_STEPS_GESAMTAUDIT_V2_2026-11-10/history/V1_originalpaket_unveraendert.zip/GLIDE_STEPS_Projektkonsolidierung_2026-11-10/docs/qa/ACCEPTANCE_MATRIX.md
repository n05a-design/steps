# Prüf- und Freigabematrix — ehrlich nach Quellstand

## Dokumentierter Ausgang, nicht neu ausgeführt

- Glide HEAD: `9e767bea5e21063466a28ac3a679406484ad5d5f`; `VERSION 3.53.0`, System V1.15.
- Glide-Report beschreibt letzte lokale **Windows**-CI-Grundstufe **19/19**, Fenster-/D77-Nachlauf und eingefrorenen Windows-Vollmodus **130/131** (eine Bildsichtung übersprungen); früheren gemessenen Rotlauf historisch erhalten; `release_ready=false`.
- Zum Prüfmoment war GitHub-Actions „Glide-Prüfung“ auf HEAD `in_progress`, paralleler macOS-arm64-Paket-Workflow `success`. **Kein daraus abgeleiteter Gesamtgrünstatus**; aktuelle Runs nachlesen.
- Steps HEAD Strukturcheck-GitHub-Actions war `success`; das beweist **nur** die Verzeichnis-/Scaffold-Prüfung, keine funktionierenden Musikfeatures.
- **In diesem Dokumentenpaket ausgeführt:** lokale Erstellung, Markdown-/Dateimanifest-/ZIP-Integritätsprüfung. **Nicht ausgeführt:** Glide-/Steps-Produktcode, native Tk-UI, pytest der Repositories, Paketbauten.

## Gateprüfung für Glide-Freeze

| Prüfart | Windows | Linux | macOS | Erforderliche Evidenz |
|---|---|---|---|---|
| statische Qualität / Python-/Ressourcenparität | berichtet bestanden | prüfen | prüfen | SHA, Python/Tk, Scripts, Exit, Report |
| Unit-/Integrations-/Datenmigration | Windows final berichtet grün | Vollmatrix offen im Bericht | Vollmatrix offen im Bericht | Fallzahl, Skips, roter Erstlauf, gleiche Source Bytes |
| nativer Paketbau + isolierter Start | individuell nachweisen | individuell nachweisen | einzelner Arm64-Bau grün beobachtet, vollständiger Start-/Matrixbeleg gesondert | Artefakthash, Laufzeit, native device/runner |
| Benutzer-/UI-Abnahme | eingeschränkte Sichtabnahme „passt alles“ | offen | offen | Designmatrix/Foto-/Fokus-/DPI-/Mehrmonitorbelege |
| Speicher/Restore/Nutzerdatenisolation | Testdaten, keine realen Nutzerverzeichnisse | ebenso | ebenso | Lock, Crash, atomic writes, backups, migration fixtures |
| Release/Publisher | keine automatische Freigabe | keine automatische Freigabe | keine automatische Freigabe | inhaltliche, rechtliche, native und menschliche Gates |

## Neue Steps-Shell Testmatrix

**Unit:** pure Theme-/Geometry-/Sidebar-State-Machines, Settings-Validator, Command Registry `enabled`/reason, NavigationItem-IDs, Path policy, contracts/ABI. **Integration:** erstellen/mounten/wechseln/dispose zweier Slot-Views; aktive Navigation, Change-Theme und Font, Sidebar hide/collapse, narrow width, restart, keyboard focus, Shortcut, Toplevel-Opt-out; künstliche Daten, keine implizite Glide-Ordnererstellung. **Negative:** destroyed widget `after` callbacks, Double Command, Out-of-order Worker, Save fails, ReadOnly, Restore, lock held, missing font/image, invalid persistent geometry, alternate Tk. **Native:** Windows 11/Tk9, Linux/Xvfb plus echter Desktop, Mac Aqua/Tk9 (soweit verfügbar); gezeigte Kombinationen sind *Testvorschläge*, nicht behauptete Ergebnisse. **Performance:** identischer synthetischer Bestand, warm-up, median/p95, UI mainloop monitor; keinen historischen anderen Host als Vergleich heranziehen.

## Musik-Domain Golden Cases

- Cmaj7 = C E G B, C7 = C E G Bb, Cm7 = C Eb G Bb (englische Tonbezeichnung, korrektes Oktav-/Registermodell).
- Deutsches H = internationales B, deutsches B = internationales Bb; UI konvertiert display-only, internes Pitch-Spelling eindeutig.
- Enharmonie F# / Gb: gleiche gleichstufige MIDI pitch class, verschiedene Notations-/Funktionskontexte. `E7 → Am` in a-Moll V7–i und in C-Dur möglicher V7/vi–vi, nicht pauschal Secondary Dominant.
- Transpose +n/-n und Roundtrip, enharmonic spell policy, Chord Inversion/Slash Bass, Timing/Duration; ambiguous analysis retains multiple plausible explanations.
- Drum Pattern rhythm, tick quantization, off-by-one Loop End, MIDI tempo meta events, note-on/off pair, channel mapping; parse exported MIDI with independent reader if available.

## Stop/Defect Policy

Kein „green by removing tests“. Neu eingeführte Schemas werden mit Migration/Fixtures getestet; ältere höhere Version read-only behandeln. Originalrote Läufe und Skips bleiben in ihrem eigenen historischen Report. Ein sachlich beendeter PR enthält **auch** nicht ausgeführte oder nur vorgeschlagene Tests. Release bleibt Owner-Gate.
