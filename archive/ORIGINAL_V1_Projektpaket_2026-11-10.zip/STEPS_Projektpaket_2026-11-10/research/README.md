# Forschungsarbeit und Marktbeobachtung

**Stand:** 10.11.2026 (Europe/Berlin). **Status:** Entwurf und Prüfauftrag, keine Umsetzung/Freigabe. **Referenzstände:** Steps `main` `75329fef46878a5ac816cef3690e612a9e8fe52c`; Glide `main` `61a2f3ac2f0e1880e7fd8c0f3cfd9da0d0c9f16d`; lokal bereitgestellter Glide-Code `3.53.0`, SHA-256 `d7e19151eb0862a8ff58c4cc5e7d06a0452cde1daa73830ff97f54247bc75271`.

**Evidenz:** `UPLOAD` = bereitgestellte Datei, `GITHUB` = gelesener Remote-Stand, `BERICHTET` = in Unterlagen behauptet, `VORSCHLAG` = neue Empfehlung, `OFFEN` = unbestätigt. Kein dokumentierter Test bedeutet nicht bestanden.

## Forschungspfade

`research/ableton` für Interviews, Produktionsbeispiele und Downloads; `research/competitors` für Chord-/Drum-Tools und Lernkonzepte; `research/papers` für kuratierte wissenschaftliche Fachquellen; `research/gaps` für offene Evidenzfragen; `research/production` für breite DAW-/Drum-/Mixing-/Mastering-Fachthemen. Der große bestehende Legacy-Bestand bleibt an seinem aktuellen tatsächlichen Git-Pfad, bis Lizenz, Referenzen und Hash-Mapping freigegeben wurden.

## Neue Crawls

Jeder Auftrag trägt `crawl_batch_id`, Ziel/Fragestellung, Domain, erlaubte Abrufmethode, Robots-/ToS-Check, Such-/Filterregeln, Zeitstempel, URL-Kanonisierung, Sprachversion/Translation Group, Quellentyp, Content-Lizenz, Diff zum Vorkatalog, `sha256`, `review_required`, `excluded_reason`. Duplikat nur nach kanonischer URL **und** Content/Edition/Hash-Prüfung. Übersetzungen und abweichende Werke nicht fälschlich verschmelzen. Externe Seiteninhalte nicht automatisch in ein öffentliches Repository hochladen. Quelle/Claim/Test-IDs für produktrelevante Inhalte erst nach fachlicher Prüfung vergeben.

## Marktforschung

Vergleiche u.a. Chord-Explorer, Harmony-Learner, Voicing-Tools, Drum-Sequencer und DAWs in den Achsen: UX, interaktive Verknüpfung, Erklärbarkeit, Theorieframework, MIDI/Audio, Offline/Privacy, Preis, Plattform, Lizenz, Bedienbarkeit, Dokumentation und Tutorial-/Learning-Layer. Bei aktuellen Preisen/Funktionen Datum und Link dokumentieren; keine aus alten Screenshots ungeprüft übertragenen Zahlen. Featureideen sind Vorschläge, keine Copy-Paste-Spezifikationen. Siehe `prompts/18_COMPETITOR_RESEARCH.md`.
